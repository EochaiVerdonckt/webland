﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PayWorld.API;
using PayWorld.API.Helpers;
using PayWorld.API.Messages.Pos;
using PayWorld.API.Messages.Device;
using Newtonsoft.Json;
using System.Web.Http;
using Microsoft.AspNetCore.Cors;

namespace PayWorld.WebAPI.Controllers
{
    // sample url http://localhost:5001/api/payworld/WalleePay
    [Route("api/[controller]")]
    [ApiController]

    public class PayWorldController : ControllerBase
    {

        // GET api/values
        [HttpGet()]
        [Route("WalleePay")]
        [EnableCors("corsAny")]
        public async Task<ActionResult<string>> WalleePay()
        {
            // Sample payment with sample data! - to be extended by implementator
            long? spaceId = 6655; // get from Wallee portal website!
            string authKey = "6likM/qdfqqsdfqsfqsfqsdfqsdfqdf="; // get from Wallee portal website!
            string applicationUserId = "00001"; // get from Wallee portal website!
            string terminalId = "000000001"; // get from Wallee portal website!
            return Ok(" { \"token\" :\"" + new Wallee(spaceId, authKey, applicationUserId, terminalId).CreateTransaction() + "\"}");
        }

        // GET api/values
        [HttpGet()]
        [Route("ping")]
        public async Task<ActionResult<string>> GetPing([FromQuery]string hostname, [FromQuery]int port, [FromQuery]int timeOut, [FromQuery]int json)
        {
            try
            {
                var result = "";
                PingRequest request = new PingRequest();

                using (PayWorldTcpClient client = new PayWorldTcpClient(hostname, port, timeOut))
                {
                    await client.Connect();
                    client.MessageReceived += Client_MessageReceived;
                    await client.SendMessage(request.PosXmlSerialize());
                    result = client.LastMassageReveived;
                    if (result == null)
                    {
                        throw new Exception("A timeout occured, the POS did not reply in time!");
                    }
                    Type responseType = PosTypeResolver.GetType(result);
                }
                if (json.Equals(1))
                {
                    result = parseToJson(result);
                }

                return result;
            }
            catch (Exception ex)
            {
                return ThrowHTTPError(ex, json);
            }

        }

        // sample url: http://localhost:5001/api/payworld/pay?hostname=192.168.0.170&port=50000&timeout=120&amount=1
        // GET api/values
        [HttpGet()]
        [Route("pay")]
        public async Task<ActionResult<string>> Pay([FromQuery]string hostname, [FromQuery]int port, [FromQuery]int timeOut, [FromQuery]string amount, [FromQuery]string posId, [FromQuery]string merchantData, [FromQuery]int json)
        {
            try
            {
                // CurrencyType.Item978 = EURO

                ulong amountPos = ulong.Parse(amount);
                FinancialTrxRequest request = new FinancialTrxRequest();
                request.posId = posId;
                request.trxData = new TransactionData() { amount = amountPos, currency = PayWorld.API.Messages.Pos.CurrencyType.Item978, transactionType = TransactionType.Purchase, additionalMerchantData = merchantData };
                var result = "";
                using (PayWorldTcpClient client = new PayWorldTcpClient(hostname, port, timeOut))
                {
                    await client.Connect();
                    client.MessageReceived += Client_MessageReceived;
                    await client.SendMessage(request.PosXmlSerialize());
                    result = client.LastMassageReveived;
                    if (result == null)
                    {
                        throw new Exception("A timeout occured, the POS did not reply in time!");
                    }

                }
                if (json.Equals(1))
                {
                    result = parseToJson(result);
                }
                return result;
            }
            catch (Exception ex)
            {
                return ThrowHTTPError(ex, json);
            }
        }

        // sample url: http://localhost:5001/api/payworld/Confirm?hostname=192.168.0.170&port=50000&confirm=0&timeout=120 
        // GET api/values
        [HttpGet()]
        [Route("ConfirmOrNot")]
        public async Task<ActionResult<string>> Confirm([FromQuery]string hostname, [FromQuery]int port, [FromQuery]int confirm, [FromQuery]int timeOut, [FromQuery]int json)
        {
            try
            {
                var result = "";
                ConfirmationResponse response = new ConfirmationResponse()
                {
                    result = byte.Parse(confirm.ToString())
                };


                using (PayWorldTcpClient client = new PayWorldTcpClient(hostname, port, timeOut))
                {
                    await client.Connect();
                    client.MessageReceived += Client_MessageReceived;
                    await client.SendMessage(response.PosXmlSerialize());
                    result = client.LastMassageReveived;
                    if (result == null)
                    {
                        throw new Exception("A timeout occured, the POS did not reply in time!");
                    }
                    Type responseType = PosTypeResolver.GetType(result);
                }
                if (json.Equals(1))
                {
                    result = parseToJson(result);
                }

                return result;
            }
            catch (Exception ex)
            {
                return ThrowHTTPError(ex, json);
            }

        }

        private string ThrowHTTPError(Exception ex, int json = 0)
        {
            HttpContext.Response.StatusCode = 500;
            ErrorNotification error = new ErrorNotification();
            error.errorText = ex.Message;
            if (json.Equals(1))
            {
                return parseToJson(error.PosXmlSerialize());
            }
            else
            {
                return error.PosXmlSerialize();
            }
        }

        private async void Client_MessageReceived(object sender, EventArgs e)
        {
            await ProcessMessage((PayWorldTcpClient)sender);
        }

        private async Task ProcessMessage(PayWorldTcpClient payWorldTcpClient)
        {
            string message = payWorldTcpClient.LastMassageReveived;
            if (!String.IsNullOrEmpty(message))
            {
                Type responseType = PosTypeResolver.GetType(message);
                if (responseType == null)
                {
                    return;
                }
                payWorldTcpClient.ContinueListening = PayWorldTcpClient.ContinueListeningToSocket(responseType);
            }
        }

        private string parseToJson(string xml)
        {
            string json = "{}";
            Type responseType = PosTypeResolver.GetType(xml);
            if (responseType.Equals(typeof(ErrorNotification)))
            {
                // sample:
                var obj = xml.PosXmlDeserialize<ErrorNotification>();
                json = JsonConvert.SerializeObject(obj);

            }
            if (responseType.Equals(typeof(DisplayNotification)))
            {
                var obj = xml.PosXmlDeserialize<DisplayNotification>();
                json = JsonConvert.SerializeObject(obj);
            }

            if (responseType.Equals(typeof(PingResponse)))
            {
                var obj = xml.PosXmlDeserialize<PingResponse>();
                json = JsonConvert.SerializeObject(obj);
            }
            if (responseType.Equals(typeof(FinancialTrxResponse)))
            {
                // sample:
                // act on this return
            }
            return json;
        }
    }
}