﻿using System;
using System.Collections.Generic;
using System.Linq;
using Wallee.Service;
using Wallee.Client;
using Wallee.Model;

namespace PayWorld.WebAPI
{
    public class Wallee
    {
        private TransactionTerminalService _transactionServiceTerminal;
        private TransactionService _transactionService;
        private TransactionCreate _transactionCreate;
        private Configuration _configuration;
        private long? _spaceId;
        private string _applicationUserID;
        private string _authenticationKey;
        private ApiResponse<Transaction> _transaction;
        private PaymentTerminal terminal;

        public Wallee(long? spaceId, string authenticationKey, string applicationUserID, string terminalIdentifier)
        {
            _spaceId = spaceId;
            _authenticationKey = authenticationKey;
            _applicationUserID = applicationUserID;

            _configuration = new Configuration(_applicationUserID, _authenticationKey);
            _transactionServiceTerminal = new TransactionTerminalService(_configuration);

            this._transactionService = new TransactionService(_configuration);
            PaymentTerminalService service = new PaymentTerminalService(_configuration);
            var listOfTerminals = service.SearchWithHttpInfo(spaceId, new EntityQuery());
            terminal = listOfTerminals.Data.Where(x => x.Identifier.Equals(terminalIdentifier)).FirstOrDefault();
        }

        public string CreateTransaction()
        {
            string result = "";
            AddressCreate billingAddress = new AddressCreate();
            billingAddress.Salutation = "Ms";
            billingAddress.GivenName = "Good";
            billingAddress.FamilyName = "Customer";
            billingAddress.Gender = Gender.FEMALE;
            billingAddress.Country = "CH";
            billingAddress.City = "Winterthur";
            billingAddress.Postcode = "8400";
            billingAddress.DateOfBirth = new DateTime(1988, 4, 19);
            billingAddress.OrganizationName = "Test GmbH";
            billingAddress.MobilePhoneNumber = "+41791234567";
            billingAddress.EmailAddress = "test@example.com";

            LineItemCreate lineItem1 = new LineItemCreate(
                name: "Item 1",
                uniqueId: "unique-id-item-1",
                type: LineItemType.PRODUCT,
                quantity: 1,
                amountIncludingTax: (decimal)0.01
            );
            lineItem1.Sku = "item-1";
            lineItem1.ShippingRequired = true;


            this._transactionCreate = new TransactionCreate(new List<LineItemCreate>() { lineItem1 });

            this._transactionCreate.BillingAddress = billingAddress;
            this._transactionCreate.ShippingAddress = billingAddress;
            this._transactionCreate.CustomerEmailAddress = billingAddress.EmailAddress;
            this._transactionCreate.CustomerId = "cutomer-x";
            this._transactionCreate.MerchantReference = Guid.NewGuid().ToString();
            this._transactionCreate.InvoiceMerchantReference = "order-1";
            this._transactionCreate.SuccessUrl = "http://localhost/success?orderId=1";
            this._transactionCreate.FailedUrl = "http://localhost/failed?orderId=1";
            this._transactionCreate.ShippingMethod = "Test Shipping";
            this._transactionCreate.ChargeRetryEnabled = false;
            //this.transactionCreate.AllowedPaymentMethodConfigurations = new List<long?>() { 8656L };
            this._transactionCreate.Language = "en-US";
            this._transactionCreate.Currency = "EUR";

            try
            {
                _transaction = this._transactionService.CreateWithHttpInfo(this._spaceId, _transactionCreate);
                result = this._transactionServiceTerminal.TillConnectionCredentials(this._spaceId, _transaction.Data.Id, terminal.Id, null);
            }
            catch (ApiException e)
            {
                return ("Failed to create transaction. Reason: " + e.Message + " Details: " + e.ErrorContent);
            }

            return result;
        }
    }
}
