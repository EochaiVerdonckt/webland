﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PayWorld.API;
using PayWorld.API.Messages.Pos;


namespace PayWorld.Tests.COM32
{
    [TestClass]
    public class COM32Tests
    {
        private bool _terminalPingTest;
        [TestMethod]
        public async Task TerminalPingTest()
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());
            Terminal terminal = new Terminal();
           
            terminal.Init("192.168.0.170", 50000, 60000);
            terminal.OnPingPongCompleted += Terminal_OnPingPongCompleted;
            terminal.OnDisplayNotificationCompleted += Terminal_OnDisplayNotificationCompleted;
            await terminal.SendPingPong();

            await Task.Delay(5000);
            Assert.IsTrue(_terminalPingTest);
        }

        private void Terminal_OnDisplayNotificationCompleted()
        {
            
        }

        private void Terminal_OnPingPongCompleted()
        {
         
            _terminalPingTest = true;
        }    

      
    }
}
