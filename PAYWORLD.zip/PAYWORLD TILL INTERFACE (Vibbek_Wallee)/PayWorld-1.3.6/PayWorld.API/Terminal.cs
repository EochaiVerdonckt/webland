﻿using PayWorld.API;
using PayWorld.API.Helpers;
using PayWorld.API.Messages.Device;
using PayWorld.API.Messages.Pos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PayWorld.API
{
    [Guid("412FD98D-1C86-4D10-869E-9E0718322172"), InterfaceType(ComInterfaceType.InterfaceIsIDispatch), ComVisible(true)]
    public interface ITerminalInterface
    {
        void Init(string ip, int port, int timeOutInMiliSecondsForTransactions);

        Task<string> SendPingPong();

        Task<string> SendTransaction(string amount, string posId);

        Task<string> SendGenericMessage(string terminalXml);

        Task<string> SendGetFinalBalance(string posId);

        Task<string> SendAbort();

        Task<string> SendConfirmationResponseNegative();

        Task<string> SendConfirmationResponsePositive();

        string GetGenericNotification();

        DisplayNotification GetDisplayNotification();

        PrinterNotification GetPrinterNotification();

        ErrorNotification GetErrorNotification();

        PingResponse GetPingResponse();

        FinancialTrxResponse GetFinancialTrxResponse();

        BeFinalBalanceResponse GetFinalBalanceResponse();

        ConfirmationRequest GetConfirmationRequest();

        string GetDisplayNotificationAsString();

        string GetPrinterNotificationAsString();

        string GetErrorNotificationAsString();

        string GetPingResponseAsString();

        string GetFinancialTrxResponseAsString();

        string GetFinalBalanceResponseAsString();

        string GetConfirmationRequestAsString();
    }

    // DispID IS REQUIRED for COM !!!   
    [Guid("6B7F689B-27F6-4437-81A9-57673F36F985"),
        InterfaceType(ComInterfaceType.InterfaceIsIDispatch), ComVisible(true)]
    public interface ITerminalEvents
    {
        [DispId(1)]
        void OnPingPongCompleted();
        [DispId(2)]
        void OnDisplayNotificationCompleted();
        [DispId(3)]
        void OnPrinterNotificationCompleted();
        [DispId(4)]
        void OnErrorNotificationCompleted();
        [DispId(5)]
        void OnConfirmationRequestCompleted();
        [DispId(6)]
        void OnFinancialTrxResponseCompleted();
        [DispId(7)]
        void OnNotificationCompleted();
    }

    [Guid("FDACA00D-8461-435E-989F-602A334EAC19"),
  ClassInterface(ClassInterfaceType.None),
  ProgId("PayWorld.API.Terminal"), ComDefaultInterface(typeof(ITerminalInterface)),
  ComSourceInterfaces(typeof(ITerminalEvents)), ComVisible(true)]

    public class Terminal : ITerminalInterface
    {
        /// <summary>
        /// Start your implementation!
        /// </summary>
        /// 

        [ComVisible(false)]
        public delegate void OnPingPongCompletedDelegate();
        public event OnPingPongCompletedDelegate OnPingPongCompleted;

        [ComVisible(false)]
        public delegate void OnDisplayNotificationCompletedDelegate();
        public event OnDisplayNotificationCompletedDelegate OnDisplayNotificationCompleted;

        [ComVisible(false)]
        public delegate void OnPrinterNotificationCompletedDelegate();
        public event OnPrinterNotificationCompletedDelegate OnPrinterNotificationCompleted;

        [ComVisible(false)]
        public delegate void OnErrorNotificationCompletedDelegate();
        public event OnPrinterNotificationCompletedDelegate OnErrorNotificationCompleted;

        [ComVisible(false)]
        public delegate void OnConfirmationRequestReceivedDelegate();
        public event OnConfirmationRequestReceivedDelegate OnConfirmationRequestReceived;

        [ComVisible(false)]
        public delegate void OnFinancialTrxResponseCompletedDelegate();
        public event OnFinancialTrxResponseCompletedDelegate OnFinancialTrxResponseCompleted;

        [ComVisible(false)]
        public delegate void OnNotificationCompletedCompletedDelegate();
        public event OnNotificationCompletedCompletedDelegate OnNotificationCompleted;

        [ComVisible(false)]
        public delegate void OnBeFinalBalanceResponseCompletedDelegate();
        public event OnBeFinalBalanceResponseCompletedDelegate OnBeFinalBalanceResponseCompleted;


        private string _ipOrHostname;
        private int _port;
        private int _timeoutInMiliSecondsForTransactions;

        public DisplayNotification GetDisplayNotification()
        {
            return TerminalActions.LastDisplayNotification;

        }

        public string GetDisplayNotificationAsString()
        {
            var result = TerminalActions.LastDisplayNotification;
            if (result != null)
                return $"{result.display.line.First()} - {result.displayType}";
            else
            {
                return "No object!";
            }
        }
        public string GetPingResponseAsString()
        {
            var result = TerminalActions.LastPingPongResponse;
            if (result != null)
            {
                return result?.server;
            }
            else
            {
                return "No object!";
            }
        }

        public PingResponse GetPingResponse()
        {
            return TerminalActions.LastPingPongResponse;
        }

        public void Init(string ipOrHostname, int port, int timeOutInMiliSecondsForTransactions)
        {
            _ipOrHostname = ipOrHostname;
            _port = port;
            _timeoutInMiliSecondsForTransactions = timeOutInMiliSecondsForTransactions;

            TerminalActions.Init(_ipOrHostname, _port, timeOutInMiliSecondsForTransactions);
            TerminalActions.OnPingPongCompleted += TerminalActions_OnPingPongCompleted;
            TerminalActions.OnDisplayNotificationCompleted += TerminalActions_OnDisplayNotificationCompleted;
            TerminalActions.OnPrinterNotificationCompleted += TerminalActions_OnPrinterNotificationCompleted;
            TerminalActions.OnErrorNotificationCompleted += TerminalActions_OnErrorNotificationCompleted;
            TerminalActions.OnConfirmationRequestCompleted += TerminalActions_OnConfirmationRequestCompleted;
            TerminalActions.OnFinancialTrxResponseCompleted += TerminalActions_OnFinancialTrxResponseCompleted;
            TerminalActions.OnNotificationCompleted += TerminalActions_OnNotificationCompleted;
            TerminalActions.OnBeFinalBalanceResponseCompleted += TerminalActions_OnBeFinalBalanceResponseCompleted;

        }

        private void TerminalActions_OnBeFinalBalanceResponseCompleted(BeFinalBalanceResponse data)
        {
            var ev = OnBeFinalBalanceResponseCompleted;
            if (ev != null)
            {
                ev();
            }
        }

        private void TerminalActions_OnNotificationCompleted(string data)
        {
            var ev = OnNotificationCompleted;
            if (ev != null)
            {
                ev();
            }
        }

        private void TerminalActions_OnFinancialTrxResponseCompleted(FinancialTrxResponse data)
        {
            var ev = OnFinancialTrxResponseCompleted;
            if (ev != null)
            {
                ev();
            }
        }

        private void TerminalActions_OnConfirmationRequestCompleted(ConfirmationRequest data)
        {
            var ev = OnConfirmationRequestReceived;
            if (ev != null)
            {
                ev();
            }
        }

        private void TerminalActions_OnErrorNotificationCompleted(ErrorNotification data)
        {
            var ev = OnErrorNotificationCompleted;
            if (ev != null)
            {
                ev();
            }
        }

        private void TerminalActions_OnPrinterNotificationCompleted(PrinterNotification data)
        {
            var ev = OnPrinterNotificationCompleted;
            if (ev != null)
            {
                ev();
            }
        }

        [ComVisible(false)]
        private void TerminalActions_OnDisplayNotificationCompleted(DisplayNotification data)
        {
            var ev = OnDisplayNotificationCompleted;
            if (ev != null)
            {
                ev();
            }
        }

        [ComVisible(false)]
        private void TerminalActions_OnPingPongCompleted(PingResponse data)
        {
            var ev = OnPingPongCompleted;
            if (ev != null)
            {
                ev();
            }
        }

        public async Task<string> SendPingPong()
        {
            return (await TerminalActions.SendPing()).Item2;
        }

        public async Task<string> SendTransaction(string amount, string posId)
        {
            return (await TerminalActions.SendTransaction(amount, posId)).Item2;
        }

        public async Task<string> SendGenericMessage(string xmlMessage)
        {
            return await TerminalActions.SendGenericMessage(xmlMessage);
        }

        public async Task<string> SendGetFinalBalance(string posId)
        {
            BeFinalBalanceRequest request = new BeFinalBalanceRequest
            {
                posId = posId,
                // trx info - receive notifications - see topic 9.1.1 trxInfo bitmask
                trxSyncNumberSpecified = false
            };

            await TerminalActions.SendGenericMessage(request.PosXmlSerialize());
            return request.PosXmlSerialize();
        }

        public async Task<string> SendAbort()
        {
            AbortCardEntryNotification request = new AbortCardEntryNotification
            {
                abortCodeSpecified = true,
                abortCode = 01
            };
            string abortXmlMessage = request.PosXmlSerialize();
            await TerminalActions.SendGenericMessage(abortXmlMessage, true);
            return abortXmlMessage;
        }

        public async Task<string> SendConfirmationResponsePositive()
        {
            ConfirmationResponse request = new ConfirmationResponse
            {
                result = 1
            };
            await TerminalActions.SendGenericMessage(request.PosXmlSerialize());
            return request.PosXmlSerialize();
        }

        public async Task<string> SendConfirmationResponseNegative()
        {
            ConfirmationResponse request = new ConfirmationResponse
            {
                result = 0
            };
            await TerminalActions.SendGenericMessage(request.PosXmlSerialize());
            return request.PosXmlSerialize();
        }

        public string GetPrinterNotificationAsString()
        {
            return TerminalActions.LastPrinterNotification?.merchantReceipt?.Value;
        }

        public PrinterNotification GetPrinterNotification()
        {
            return TerminalActions.LastPrinterNotification;
        }

        public string GetErrorNotificationAsString()
        {
            if (TerminalActions.LastErrorNotification.cardId != null)
            {
                return $"Cardid: {TerminalActions.LastErrorNotification.cardId} - {TerminalActions.LastErrorNotification.errorText}";
            }
            else
            {
                return $"{TerminalActions.LastErrorNotification.errorText}";
            }
        }

        public ErrorNotification GetErrorNotification()
        {
            return TerminalActions.LastErrorNotification;
        }

        public string GetGenericNotification()
        {
            return TerminalActions.LastNotification;
        }

        public string GetFinancialTrxResponseAsString()
        {
            return "ERROR: NOT YET IMPLEMENTED";
        }

        public FinancialTrxResponse GetFinancialTrxResponse()
        {
            return TerminalActions.LastFinancialTrxResponse;
        }

        public string GetFinalBalanceResponseAsString()
        {
            return TerminalActions.LastBeFinalBalanceResponse.trxSyncNumber.ToString();
        }

        public BeFinalBalanceResponse GetFinalBalanceResponse()
        {
            return TerminalActions.LastBeFinalBalanceResponse;
        }

        public string GetConfirmationRequestAsString()
        {
            ConfirmationRequest data = TerminalActions.LastConfirmationRequest;
            var result = data.displayType.ToString();
            if (data.display != null)
            {
                result += Environment.NewLine;
                foreach (string s in data.display.line)
                {
                    result += s + Environment.NewLine;
                }
            }
            return result;
        }

        public ConfirmationRequest GetConfirmationRequest()
        {
            return TerminalActions.LastConfirmationRequest;
        }
    }
}
