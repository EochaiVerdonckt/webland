﻿namespace com.vibbek.client.pos
{
	using com.vibbek.client.pos.message;

	/// <summary>
	/// The classes which implement this interface handle the requests which the PoS receives from the VPJ.
	/// 
	/// @author mkitschke
	/// 
	/// </summary>
	public interface IPosRequestHandler
	{

		/// <summary>
		/// This method handles a confirmation request that was received from the VPJ.
		/// </summary>
		/// <param name="confirmationRequest"> confirmationRequest.
		/// </param>
		/// <returns> a <seealso cref="POSConfirmationResponse"/> or a <seealso cref="POSTimeoutNotification"/> object. </returns>
		IPOSMessage handleConfirmationRequest(POSConfirmationRequest confirmationRequest);

		/// <summary>
		/// This method handles a Manor transaction modification request that was received from the VPJ.
		/// </summary>
		/// <param name="manorTrxModificationRequest">
		///            received Manor transaction modification request.
		/// </param>
		/// <returns> a <seealso cref="POSManorTrxModificationResponse"/> containing the possibly modified transaction data or a
		///         <seealso cref="POSTimeoutNotification"/> if the data was not provided in time. </returns>
		IPOSMessage handleManorTrxModificationRequest(POSManorTrxModificationRequest manorTrxModificationRequest);
	}

}