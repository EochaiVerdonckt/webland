﻿namespace com.vibbek.client.pos
{
	using com.vibbek.client.pos.message;

	/// <summary>
	/// This class processes the requests that the simulated PoS receives from a VPJ. This class simulates a PoS.
	/// 
	/// @author mkitschke
	/// 
	/// </summary>
	public class NoRealPosHandler : IPosRequestHandler
	{

		private readonly IPosInteractionHandler posInteractionHandler;

		/// <param name="posInteractionHandler"> posInteractionHandler </param>
//JAVA TO C# CONVERTER WARNING: 'final' parameters are ignored unless the option to convert to C# 7.2 'in' parameters is selected:
//ORIGINAL LINE: public NoRealPosHandler(final IPosInteractionHandler posInteractionHandler)
		public NoRealPosHandler(IPosInteractionHandler posInteractionHandler)
		{
			this.posInteractionHandler = posInteractionHandler;
		}

//JAVA TO C# CONVERTER WARNING: 'final' parameters are ignored unless the option to convert to C# 7.2 'in' parameters is selected:
//ORIGINAL LINE: @Override public IPOSMessage handleConfirmationRequest(final POSConfirmationRequest confirmationRequest)
		public virtual IPOSMessage handleConfirmationRequest(POSConfirmationRequest confirmationRequest)
		{
			return posInteractionHandler.showConfirmationRequestDialog(int.Parse(confirmationRequest.Timeout));
		}

//JAVA TO C# CONVERTER WARNING: 'final' parameters are ignored unless the option to convert to C# 7.2 'in' parameters is selected:
//ORIGINAL LINE: @Override public IPOSMessage handleManorTrxModificationRequest(final POSManorTrxModificationRequest manorTrxModificationRequest)
		public virtual IPOSMessage handleManorTrxModificationRequest(POSManorTrxModificationRequest manorTrxModificationRequest)
		{
			return posInteractionHandler.showManorTransactionModificationDialog();
		}
	}

}