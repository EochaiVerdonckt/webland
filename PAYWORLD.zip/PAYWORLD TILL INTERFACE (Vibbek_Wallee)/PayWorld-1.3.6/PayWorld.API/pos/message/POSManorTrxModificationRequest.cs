﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// A message sent from the VPJ to the POS to request a possible modification of the transaction data for Manor cards.<br>
	/// The decision of the POS to modify some transaction data is based on the data provided in this request.
	/// 
	/// @author dbuck
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "manorTrxModificationRequest", namespace = "http://www.vibbek.com/device") public class POSManorTrxModificationRequest implements IPOSMessage
	public class POSManorTrxModificationRequest : IPOSMessage
	{

		private string primaryAccountNumber;
		private string cardholderName;
		private int? industryCode;
		private string applicationExpirationDate;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "PAN") public String getPrimaryAccountNumber()
		public virtual string PrimaryAccountNumber
		{
			get
			{
				return this.primaryAccountNumber;
			}
			set
			{
				this.primaryAccountNumber = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardholderName") public String getCardholderName()
		public virtual string CardholderName
		{
			get
			{
				return this.cardholderName;
			}
			set
			{
				this.cardholderName = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "industryCode") public System.Nullable<int> getIndustryCode()
		public virtual int? IndustryCode
		{
			get
			{
				return this.industryCode;
			}
			set
			{
				this.industryCode = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "applicationExpirationDate") public String getApplicationExpirationDate()
		public virtual string ApplicationExpirationDate
		{
			get
			{
				return this.applicationExpirationDate;
			}
			set
			{
				this.applicationExpirationDate = value;
			}
		}

	}

}