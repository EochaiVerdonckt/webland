﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// PoS requests a transaction abort triggered from attendant.
	/// 
	/// @author areiff
	/// 
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "abortCardEntryNotification", namespace = "http://www.vibbek.com/device") public class POSAbortCardEntryNotification implements IPOSMessage
	public class POSAbortCardEntryNotification : IPOSMessage
	{

	}

}