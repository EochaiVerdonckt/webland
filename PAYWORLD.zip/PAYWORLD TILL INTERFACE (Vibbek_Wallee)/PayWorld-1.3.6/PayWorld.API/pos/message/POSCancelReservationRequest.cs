﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// This class represents a request to the VCS to cancel a reservation, according to EP2 V6.2.0.
	/// 
	/// @author areiff
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "cancelReservationRequest") public class POSCancelReservationRequest extends AbstractPOSRequest
	public class POSCancelReservationRequest : AbstractPOSRequest
	{
		private string acquirerId;
		private string transactionRefNumber;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "acquirerId", required = true) public String getAcquirerId()
		public virtual string AcquirerId
		{
			get
			{
				return this.acquirerId;
			}
			set
			{
				this.acquirerId = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "transactionRefNumber", required = true) public String getTransactionRefNumber()
		public virtual string TransactionRefNumber
		{
			get
			{
				return this.transactionRefNumber;
			}
			set
			{
				this.transactionRefNumber = value;
			}
		}


	}

}