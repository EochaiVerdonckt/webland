﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// This class is a generic wrapper to use for requests to send to
	/// the Vibbek CS via VPJ.
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "financialTrxRequest") public class POSPaymentRequest extends AbstractPOSRequest
	public class POSPaymentRequest : AbstractPOSRequest
	{

		private POSTransactionData trxData;

		private POSManualPanData manualPanData;

		private POSBarcodeCardData barcodeCardData;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "trxData") public POSTransactionData getTrxData()
		public virtual POSTransactionData TrxData
		{
			get
			{
				return this.trxData;
			}
			set
			{
				this.trxData = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "manualPanData") public POSManualPanData getManualPanData()
		public virtual POSManualPanData ManualPanData
		{
			get
			{
				return this.manualPanData;
			}
			set
			{
				this.manualPanData = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardTokenData") public POSBarcodeCardData getBarcodeCardData()
		public virtual POSBarcodeCardData BarcodeCardData
		{
			get
			{
				return this.barcodeCardData;
			}
			set
			{
				this.barcodeCardData = value;
			}
		}


	}

}