﻿using System.Collections.Generic;

namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// A confirmation request which the VPJ can send to the PoS. 
	/// 
	/// @author mkitschke
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "confirmationRequest", namespace = "http://www.vibbek.com/device") public class POSConfirmationRequest implements IPOSMessage
	public class POSConfirmationRequest : IPOSMessage
	{

		/// <summary>
		/// The lines of text which can be shown on a display.
		/// 
		/// @author mkitschke
		/// </summary>
		public class DisplayItem
		{

			internal IList<string> lines = new List<string>();

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "line") public List<String> getLines()
			public virtual IList<string> Lines
			{
				get
				{
					return this.lines;
				}
				set
				{
					this.lines = value;
				}
			}

		}

		private DisplayItem display;
		private string timeout;
		private string timeoutReminder;

		/// <summary>
		/// Returns the list of display lines.
		/// </summary>
		/// <returns> the list of display lines. </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "display") public DisplayItem getDisplay()
		public virtual DisplayItem Display
		{
			get
			{
				return this.display;
			}
			set
			{
				this.display = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "timeout") public String getTimeout()
		public virtual string Timeout
		{
			get
			{
				return timeout;
			}
			set
			{
				this.timeout = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "timeoutReminder") public String getTimeoutReminder()
		public virtual string TimeoutReminder
		{
			get
			{
				return timeoutReminder;
			}
			set
			{
				this.timeoutReminder = value;
			}
		}

	}

}