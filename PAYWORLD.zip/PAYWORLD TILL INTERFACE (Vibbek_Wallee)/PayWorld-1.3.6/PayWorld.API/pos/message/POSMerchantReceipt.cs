﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Container storing a merchant receipt and meta-data.
	/// 
	/// @author aguenther
	/// </summary>
	public class POSMerchantReceipt
	{

		private string text;
		private bool? admin;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlValue public String getText()
		public virtual string Text
		{
			get
			{
				return text;
			}
			set
			{
				this.text = value;
			}
		}


		/// <summary>
		/// Returns the administrative flag.
		/// 
		/// The administrative flags marks a receipt which is not a financial transaction receipt like day-end, activation etc.
		/// </summary>
		/// <returns> the administrative flag or <code>null</code> if not set. </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlAttribute(name = "admin", required = false) public System.Nullable<bool> isAdmin()
		public virtual bool? Admin
		{
			get
			{
				return admin;
			}
			set
			{
				this.admin = value;
			}
		}


	}

}