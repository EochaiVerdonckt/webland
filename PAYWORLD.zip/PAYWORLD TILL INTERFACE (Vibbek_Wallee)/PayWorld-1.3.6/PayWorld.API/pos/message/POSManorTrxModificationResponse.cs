﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// The PoS sends this response to the VPJ in response to the <seealso cref="POSManorTrxModificationRequest"/>.
	/// It contains possibly modified transaction data for Manor cards depending on the data provided in the request.
	/// 
	/// @author dbuck
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "manorTrxModificationResponse", namespace = "http://www.vibbek.com/device") public class POSManorTrxModificationResponse implements IPOSMessage
	public class POSManorTrxModificationResponse : IPOSMessage
	{

		private string amount;
		private string pan;
		private string forceOnline;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "amount") public String getAmount()
		public virtual string Amount
		{
			get
			{
				return this.amount;
			}
			set
			{
				this.amount = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "PAN") public String getPan()
		public virtual string Pan
		{
			get
			{
				return pan;
			}
			set
			{
				this.pan = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "forceOnline") public String getForceOnline()
		public virtual string ForceOnline
		{
			get
			{
				return this.forceOnline;
			}
			set
			{
				this.forceOnline = value;
			}
		}

	}

}