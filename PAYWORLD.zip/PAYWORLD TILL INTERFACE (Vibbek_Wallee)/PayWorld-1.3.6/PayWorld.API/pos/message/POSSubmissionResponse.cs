﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Response to a <seealso cref="POSSubmissionRequest"/> message.
	/// 
	/// @author carstenmeyer
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "miSubmissionResponse") public class POSSubmissionResponse implements IPOSResponse
	public class POSSubmissionResponse : IPOSResponse
	{

	}

}