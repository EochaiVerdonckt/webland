﻿using System.Collections.Generic;

namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Response to the <seealso cref="POSConfigDataResponse"/> containing the requested configuration data.
	/// 
	/// @author aguenther
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "configDataResponse") public class POSConfigDataResponse implements IPOSResponse
	public class POSConfigDataResponse : IPOSResponse
	{

		private POSTerminalConfigDataContainer terminalConfigData;
		private string ep2Version;
		private IList<POSAcquirerDataContainer> acquirerDataList;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2Tcd", required = false) public POSTerminalConfigDataContainer getTerminalConfigData()
		public virtual POSTerminalConfigDataContainer TerminalConfigData
		{
			get
			{
				return terminalConfigData;
			}
			set
			{
				this.terminalConfigData = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2Version", required = false) public String getEp2Version()
		public virtual string Ep2Version
		{
			get
			{
				return ep2Version;
			}
			set
			{
				this.ep2Version = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElementWrapper(name = "acquirerDataList", required = false) @XmlElement(name = "acquirerData", required = false) public java.util.List<POSAcquirerDataContainer> getAcquirerDataList()
		public virtual IList<POSAcquirerDataContainer> AcquirerDataList
		{
			get
			{
				return acquirerDataList;
			}
			set
			{
				this.acquirerDataList = value;
			}
		}

	}

}