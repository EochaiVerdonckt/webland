﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// This class represents a request to the VCS to revert the
	/// last transaction, according to EP2.
	/// 
	/// @author aflaegel
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "reversalRequest") public class POSReversalRequest extends AbstractPOSRequest
	public class POSReversalRequest : AbstractPOSRequest
	{

		private string additionalMerchantData;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "additionalMerchantData") public String getAdditionalMerchantData()
		public virtual string AdditionalMerchantData
		{
			get
			{
				return this.additionalMerchantData;
			}
			set
			{
				this.additionalMerchantData = value;
			}
		}

	}

}