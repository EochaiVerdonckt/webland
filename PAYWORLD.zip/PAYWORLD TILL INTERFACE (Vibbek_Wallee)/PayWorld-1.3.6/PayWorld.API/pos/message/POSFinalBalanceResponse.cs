﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instances of this class represent the response to a <seealso cref="POSFinalBalanceRequest"/>.
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "beFinalBalanceResponse") public class POSFinalBalanceResponse implements IPOSResponse
	public class POSFinalBalanceResponse : IPOSResponse
	{

	}

}