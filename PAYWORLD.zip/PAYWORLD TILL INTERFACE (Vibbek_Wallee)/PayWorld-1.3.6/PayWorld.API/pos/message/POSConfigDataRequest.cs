﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Request for terminal configuration data.
	/// 
	/// @author aguenther
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "configDataRequest") public class POSConfigDataRequest extends AbstractPOSRequest
	public class POSConfigDataRequest : AbstractPOSRequest
	{
		// No additional contents.
	}

}