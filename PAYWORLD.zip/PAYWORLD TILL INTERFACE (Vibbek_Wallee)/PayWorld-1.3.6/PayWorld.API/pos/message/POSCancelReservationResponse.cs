﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Response message of a <seealso cref="POSCancelReservationRequest"/> message.
	/// 
	/// @author areiff
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "cancelReservationResponse") public class POSCancelReservationResponse implements IPOSResponse
	public class POSCancelReservationResponse : IPOSResponse
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlEnum(String.class) public enum CancelReservationResultType
		public enum CancelReservationResultType
		{
			OK,
			FAILED
		}

	 // general response fields
		private string amountAuth;
		private string amountAuthCurr;
		private CancelReservationResultType result;
		private string acquirerId;
		private string transactionRefNumber;
		private string trxTime;

		// ep2 response fields
		private string ep2AuthResult;
		private string ep2TrmId;
		private string ep2TrxSeqCnt;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "amountAuth") public String getAmountAuth()
		public virtual string AmountAuth
		{
			get
			{
				return this.amountAuth;
			}
			set
			{
				this.amountAuth = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "amountAuthCurr") public String getAmountAuthCurr()
		public virtual string AmountAuthCurr
		{
			get
			{
				return this.amountAuthCurr;
			}
			set
			{
				this.amountAuthCurr = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "result") public CancelReservationResultType getResult()
		public virtual CancelReservationResultType Result
		{
			get
			{
				return this.result;
			}
			set
			{
				this.result = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2AuthResult") public String getEp2AuthResult()
		public virtual string Ep2AuthResult
		{
			get
			{
				return this.ep2AuthResult;
			}
			set
			{
				this.ep2AuthResult = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2TrmId") public String getEp2TrmId()
		public virtual string Ep2TrmId
		{
			get
			{
				return this.ep2TrmId;
			}
			set
			{
				this.ep2TrmId = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "acqId") public String getAcquirerId()
		public virtual string AcquirerId
		{
			get
			{
				return this.acquirerId;
			}
			set
			{
				this.acquirerId = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "transactionRefNumber") public String getTransactionRefNumber()
		public virtual string TransactionRefNumber
		{
			get
			{
				return this.transactionRefNumber;
			}
			set
			{
				this.transactionRefNumber = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "trxTime") public String getTrxTime()
		public virtual string TrxTime
		{
			get
			{
				return this.trxTime;
			}
			set
			{
				this.trxTime = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2TrxSeqCnt") public String getEp2TrxSeqCnt()
		public virtual string Ep2TrxSeqCnt
		{
			get
			{
				return this.ep2TrxSeqCnt;
			}
			set
			{
				this.ep2TrxSeqCnt = value;
			}
		}


	}

}