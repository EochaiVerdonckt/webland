﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instaces of this class represent requests to the Vibbek CS to
	/// activate the terminal corresponding to the ClientId passed as
	/// argument.
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "activationRequest") public class POSActivationRequest extends AbstractPOSRequest
	public class POSActivationRequest : AbstractPOSRequest
	{

		private string language;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "language") public String getLanguage()
		public virtual string Language
		{
			get
			{
				return this.language;
			}
			set
			{
				this.language = value;
			}
		}


	}

}