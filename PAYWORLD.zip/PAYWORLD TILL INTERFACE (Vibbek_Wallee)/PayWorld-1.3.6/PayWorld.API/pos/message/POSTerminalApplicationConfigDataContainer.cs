﻿namespace com.vibbek.client.pos.message
{

	using ByteArray = com.vibbek.util.misc.ByteArray;

	/// <summary>
	/// Container for card application configuration data.
	/// 
	/// @author aguenther
	/// </summary>
	public class POSTerminalApplicationConfigDataContainer
	{

		private sbyte[] aid;
		private string brand;
		private string readerTechnologyType;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "aid", required = false) public byte[] getAid()
		public virtual sbyte[] Aid
		{
			get
			{
				return ByteArray.copy(aid);
			}
			set
			{
				this.aid = ByteArray.copy(value);
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "brand", required = false) public String getBrand()
		public virtual string Brand
		{
			get
			{
				return brand;
			}
			set
			{
				this.brand = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "readerTechnology", required = false) public String getReaderTechnologyType()
		public virtual string ReaderTechnologyType
		{
			get
			{
				return readerTechnologyType;
			}
			set
			{
				this.readerTechnologyType = value;
			}
		}

	}

}