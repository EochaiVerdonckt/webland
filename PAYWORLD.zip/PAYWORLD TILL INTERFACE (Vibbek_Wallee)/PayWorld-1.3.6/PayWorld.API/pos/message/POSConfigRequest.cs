﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instances of this class represent a request to the VCS to configure
	/// a terminal.
	/// 
	/// @author aflaegel
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "siConfigRequest") public class POSConfigRequest extends AbstractPOSRequest
	public class POSConfigRequest : AbstractPOSRequest
	{

	}

}