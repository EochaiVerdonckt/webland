﻿namespace com.vibbek.client.pos.message
{
	/// <summary>
	/// This is the common interface to all responses the client receives from
	/// the Vibbek CS via VPJ. Currently, there are no common methods, so this
	/// is basically a marker interface.
	/// </summary>
	public interface IPOSResponse : IPOSMessage
	{

	}

}