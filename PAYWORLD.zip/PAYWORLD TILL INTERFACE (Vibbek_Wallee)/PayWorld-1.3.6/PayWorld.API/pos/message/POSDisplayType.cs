﻿namespace com.vibbek.client.pos.message
{
	/// <summary>
	/// Type of display.
	/// 
	/// @author areiff
	/// </summary>
	public enum POSDisplayType
	{
		CARDHOLDER,
		ATTENDANT
	}

}