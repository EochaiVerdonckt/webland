﻿/// <summary>
/// This package contains classes to be used by a POS system
/// to send requests to the Vibbek Central Server. Communication
/// with the VCS always is performed using an implementation
/// of the Vibbek POS Junction (VPJ), usually located on a
/// PINPad device that provides the necessary security functions.
/// 
/// </summary>
namespace com.vibbek.client.pos
{
}