﻿using System;

namespace com.vibbek.client.pos
{
	/// <summary>
	/// This exceptions is thrown when an error in the communication with an
	/// external device of system occurs.
	/// </summary>
	public class CommunicationException : Exception
	{

		private const long serialVersionUID = 1L;

		/// <summary>
		/// This constructor accepts a simple message as argument. </summary>
		/// <param name="message"> The message describing the exception </param>
//JAVA TO C# CONVERTER WARNING: 'final' parameters are ignored unless the option to convert to C# 7.2 'in' parameters is selected:
//ORIGINAL LINE: public CommunicationException(final String message)
		public CommunicationException(string message) : base(message)
		{
		}

		/// <summary>
		/// This constructor accepts a message and the ause of this exception (another exception)
		/// as arguments. </summary>
		/// <param name="message"> The message describing this exception </param>
		/// <param name="cause"> The cause of this exception. </param>
//JAVA TO C# CONVERTER WARNING: 'final' parameters are ignored unless the option to convert to C# 7.2 'in' parameters is selected:
//ORIGINAL LINE: public CommunicationException(final String message, final Throwable cause)
		public CommunicationException(string message, Exception cause) : base(message, cause)
		{
		}

	}

}