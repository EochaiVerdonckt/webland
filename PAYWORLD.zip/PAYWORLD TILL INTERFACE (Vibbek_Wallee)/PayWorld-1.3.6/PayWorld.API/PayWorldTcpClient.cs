﻿using PayWorld.API.Helpers;
using PayWorld.API.Messages.Device;
using PayWorld.API.Messages.Pos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PayWorld.API
{
    /// <summary>
    /// TCP IP client helper class to facilitate easy communication with PayWorld payterminal.
    /// </summary>
    public class PayWorldTcpClient : IDisposable
    {
        public event EventHandler MessageReceived;
        private int _socketPort;
        private int _timeOutInMiliSecondsForTransactions;
        //private int _connectionTimout;
        private String _ipOrHostNameOfPayTerminal;
        public string LastMassageReveived;
        public bool ContinueListening = true;
        public TcpClient _client;
        public NetworkStream _stream;
        public string AbortMessage;
        public bool Abort = false;


        public PayWorldTcpClient(String ipOrHostNameOfPayTerminal, int socketPort, int timeOutInMiliSecondsForTransactions)
        {
            _ipOrHostNameOfPayTerminal = ipOrHostNameOfPayTerminal;
            _socketPort = socketPort;

            _timeOutInMiliSecondsForTransactions = timeOutInMiliSecondsForTransactions;

        }

        public async Task Connect()
        {
            _client = new TcpClient();
            CancellationTokenSource source = new CancellationTokenSource();
            CancellationToken token = source.Token;
            await _client.ConnectAsyncWithCancel(_ipOrHostNameOfPayTerminal, _socketPort, token);
            int timer = 0;
            while (!_client.Connected)
            {
                await Task.Delay(1000);
                timer += 1;
                if (timer.Equals(3))
                {
                    source.Cancel();
                    break;
                }

            }
            // bool success = result.AsyncWaitHandle.WaitOne(_connectionTimout * 1000, true);
            if (!_client.Connected)
            {
                // NOTE, MUST CLOSE THE SOCKET

                Dispose();

                throw new ApplicationException("Connection to PINPAD failed!");
            }
        }

        protected virtual void OnMessageReceived(EventArgs e)
        {
            EventHandler handler = MessageReceived;
            handler?.Invoke(this, e);
        }

        public void AbortTransaction(string message)
        {
            AbortMessage = message;
            Abort = true;
        }


        public static void Read_Callback(IAsyncResult ar)
        {



        }
        /// <summary>
        /// Sends a message to the pay terminal! All excecptions should be handled by the implementation. 
        /// </summary>
        /// <param name="ipOrHostNameOfPayTerminal"></param>
        /// <param name="port"></param>
        /// <param name="message"></param>
        /// <param name="timeOut"></param>
        /// <returns>The response of the payterminal.</returns>
        public async Task<string> SendMessage(String message)
        {
            String responseData = "";          
            try
            {

                // Create a TcpClient.
                // String to store the response UTF-8 representation.



                _client.SendTimeout = _timeOutInMiliSecondsForTransactions;
                _client.ReceiveTimeout = _timeOutInMiliSecondsForTransactions;

                // translate the passed message into UTF-8 byte array with the correct prefix bytes.
                Byte[] data = SocketHelper.PosData(message);

                // Get a client stream for reading and writing.
                _stream = _client.GetStream();

                // Send the message to the connected TcpServer. 
                await _stream.WriteAsync(data, 0, data.Length);
                while (ContinueListening)
                {
                    // Receive the TcpServer.response.
                    // Buffer to store the response bytes. (at first we only read the first 4 bytes to know the length of the returning message.

                    while (!_stream.DataAvailable && !Abort)
                    {
                        await Task.Delay(100);                      
                    }
                    if (Abort)
                    {
                        Byte[] dataAbort = SocketHelper.PosData(AbortMessage);
                        //cancellationToken.Cancel();
                        await _stream.WriteAsync(dataAbort, 0, dataAbort.Length);
                    }

                    data = new Byte[4];
                 
                    // Read the first batch of the TcpServer/payterminal response bytes.
                    Int32 bytes = _stream.Read(data, 0, data.Length);
                    int length = SocketHelper.PosReturnLength(data);
                    // Read the second batch of the TcpServer/payterminal response bytes.
                    data = new Byte[length];
                    await _stream.ReadAsync(data, 0, length);

                    responseData = new UTF8Encoding(false).GetString(data);

                    LastMassageReveived = responseData;

                    Type responseType = PosTypeResolver.GetType(LastMassageReveived);
                    ContinueListening = ContinueListeningToSocket(responseType);
                    OnMessageReceived(EventArgs.Empty);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ERROR - " + ex.Message);
                Dispose();
                throw ex;
            }
            return responseData;

        }

        public static bool ContinueListeningToSocket(Type responseType)
        {
            if (responseType == null)
            {
                return true;
            }
            if (responseType.Equals(typeof(PingResponse)) || responseType.Equals(typeof(ErrorNotification)) || responseType.Equals(typeof(FinancialTrxResponse)) || responseType.Equals(typeof(ConfirmationRequest)) || responseType.Equals(typeof(BeFinalBalanceResponse)))
            {
                return false;
            }       
            return true;
        }

        public void Dispose()
        {
            ContinueListening = false;

            _stream?.Close();
            _stream?.Dispose();
            _client?.Close();
            _client?.Dispose();

        }
    }
}
