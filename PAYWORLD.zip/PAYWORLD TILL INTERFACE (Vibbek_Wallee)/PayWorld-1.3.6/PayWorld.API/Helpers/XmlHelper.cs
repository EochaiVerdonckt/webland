﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace PayWorld.API.Helpers
{
    public static class XmlHelper
    {
        public static string PosXmlSerialize<T>(this T objectToSerialize)
        {

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), "http://www.vibbek.com/pos");
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add("vcs-pos", "http://www.vibbek.com/pos");
            ns.Add("vcs-device", "http://www.vibbek.com/device");

            using (MemoryStream ms = new MemoryStream())
            {
                using (XmlTextWriter xmlWriter = new XmlTextWriter(ms, new UTF8Encoding(false)))
                {
                    xmlWriter.WriteStartDocument(true);
                    xmlWriter.Formatting = Formatting.Indented;
                    xmlSerializer.Serialize(xmlWriter, objectToSerialize, ns);
                    return new UTF8Encoding(false).GetString(ms.ToArray());
                }
            }
        }

        public static T PosXmlDeserialize<T>(this string xml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));

            using (var stream = new MemoryStream())
            {
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)))
                {
                    writer.Write(xml);
                    writer.Flush();
                    stream.Position = 0;
                    return (T)xmlSerializer.Deserialize(stream);
                }
            }
        }
    }
}