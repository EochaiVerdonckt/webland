﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayWorld.API.Helpers
{
    public static class TransactionType
    {
        public static byte Purchase
        {
            get { return Convert.ToByte(0);  }
        }

        public static byte PurchaseReservation
        {
            get { return Convert.ToByte(1); }
        }

        // to be extended if needed ...
        /*
            <xsd:enumeration value="0" /> <!-- Purchase -->
            <xsd:enumeration value="1" /> <!-- Purchase Reservation -->
            <xsd:enumeration value="3" /> <!-- Cash Advance -->
            <xsd:enumeration value="4" /> <!-- Credit -->
            <xsd:enumeration value="5" /> <!-- Purchase phone authorized -->
            <xsd:enumeration value="6" /> <!-- Purchase force acceptance -->
            <xsd:enumeration value="11" /> <!-- Purchase with cashback -->
            <xsd:enumeration value="12" /> <!-- Load -->
            <xsd:enumeration value="50" /> <!-- Reservation -->
            <xsd:enumeration value="51" /> <!-- Reservation adjustment -->
            <xsd:enumeration value="52" /> <!-- Confirm phone authorized reservation -->
            <xsd:enumeration value="53" /> <!-- Balance Inquiry -->
            <xsd:enumeration value="57" /> <!-- Activate Card -->
         */
    }
}
