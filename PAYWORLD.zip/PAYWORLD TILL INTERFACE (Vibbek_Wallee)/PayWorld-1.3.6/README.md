# PayWorld .NET API

This is an intro to the PayWorld sample solution (Visual Studio 2019) to integrate your POS application or website with the PayWorld terminal.

If you want to integrate. Reference the PayWorld.API or PayWorld.API.NET4.

Keep in mind that the solution is setup as x64 bit. This can be changed to x86 if needed. 

There are 3 sample implementations.

## PayWorld POS demo application
  * Simple WPF app thats allows you to send transactions the terminal and gives you some info around the communication between the app and the terminal..
## PayWorld.WebAPI
  * A small sample how you could integrate the solution via a WebAPI
## PayWorld Wallee (inside PayWorld.WebAPI)
  * A small sample how to integrate PayWorld through Wallee
## PayWorld COM 
  * PayWorld.API.NET4 can be registered as a .NET COM object. through REGASM
  * Sample implementation through vbscript (see PayWorld.COM.vbe)
    * 32bit (change project platform target first) c:\Windows\Microsoft.NET\Framework\v4.0.30319\RegAsm.exe /codebase [path to PayWorld.API.NET4.dll]
    * 64bit c:\Windows\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe /codebase [path to PayWorld.API.NET4.dll]

These using statements will give you everything you need:

    using PayWorld.API;
    using PayWorld.API.Helpers;
    using PayWorld.API.Messages.Device;
    using PayWorld.API.Messages.Pos;

The base implementation:

    string terminalReturnMessage = new PayWorldTcpClient(hostname, port, timeOutInMs).SendMessage(request);
    
However we created a nice class to easily talk to the terminal!

PayWorld.API.Terminal

    private Terminal _payWorldTerminal = new Terminal();
    _payWorldTerminal.Init(hostname, port, timeOutInMs);
    SubscribeToEvents();
    await _payWorldTerminal.SendPingPong();

    private void SubscribeToEvents()
    {
        if (_payWorldTerminal != null)
        {
            _payWorldTerminal.OnConfirmationRequestReceived += _payWorldTerminal_OnConfirmationRequestReceived;                
            _payWorldTerminal.OnDisplayNotificationCompleted += _payWorldTerminal_OnDisplayNotificationCompleted;
            _payWorldTerminal.OnErrorNotificationCompleted += _payWorldTerminal_OnErrorNotificationCompleted;
            _payWorldTerminal.OnPingPongCompleted += _payWorldTerminal_OnPingPongCompleted;
            _payWorldTerminal.OnPrinterNotificationCompleted += _payWorldTerminal_OnPrinterNotificationCompleted;
            _payWorldTerminal.OnFinancialTrxResponseCompleted += _payWorldTerminal_OnFinancialTrxResponseCompleted;
        }
    }