﻿using PayWorld.Helpers;
using PayWorld.Viewmodel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace PayWorld
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
          
            Process proc = Process.GetCurrentProcess();
            int count = Process.GetProcesses().Where(p =>
                p.ProcessName == proc.ProcessName).Count();

            if (count > 1)
            {
                MessageBox.Show("PayWorld is already running... . Please close the other instance first!");
                App.Current.Shutdown();
            }
            MainWindow mainWindow = new MainWindow();
            //if (startMinimized)
            //{
            //    mainWindow.WindowState = WindowState.Minimized;
            //}
            foreach (string arg in e.Args)
            {
                Debug.WriteLine(arg);
            }
            Log.Init();
            mainWindow.Show();

            try
            {
                decimal value = Convert.ToDecimal(e.Args[0].Replace('.', ','));
                string amount = value.ToString();
                (mainWindow.DataContext as MainWindowViewmodel).Amount = amount.Replace(',', '.');
            }
            catch (Exception)
            {
                (mainWindow.DataContext as MainWindowViewmodel).Amount = "";
            }

        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
           
        }
    }
}
