﻿using PayWorld.API;
using PayWorld.API.Helpers;
using PayWorld.API.Messages.Device;
using PayWorld.API.Messages.Pos;
using PayWorld.Helpers;
using PayWorld.Viewmodel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using System.IO;
using System.Windows.Forms;

namespace PayWorld.Viewmodel
{
    public class MainWindowViewmodel : BaseViewModel
    {

        private Terminal _payWorldTerminal = new Terminal();
        private bool _lastMessageConfirmationRequest = false;
        private int _hasAbortErrorOnStartupHappend;
        private bool _isFinalBalancePrinting = false;
        private string _finalBalanceWorkPath;
        private Timer timer1;
        private const string URL = "https://buenaonda.be/api/TerminalApi.php";
        private string urlParameters = "?api_key=123";

        public class Terminal_payment
        {
            public int Id { get; set; }
            public decimal Amount { get; set; }
            public string Send { get; set; }
        }
        public MainWindowViewmodel()
        {
            init();
        }

        private async void init()
        {
            try
            {
                LoadSettings();
                _finalBalanceWorkPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\FinalBalanceLogs";
                if (!Directory.Exists(_finalBalanceWorkPath))
                    Directory.CreateDirectory(_finalBalanceWorkPath);
                // DisplayOrPrint = new ObservableCollection<string>();
                // FinalBalanceResult = new ObservableCollection<string>();
                _payWorldTerminal.Init(IpOrHostname, Convert.ToInt32(Port), Convert.ToInt32(TimeOut) * 1000);
                SubscribeToEvents();
                // Fix to make sure init goes well and socket is reset   
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }
        public void InitTimer()
        {
            timer1 = new Timer();
            timer1.Tick += new EventHandler(timer1_Tick);
            timer1.Interval = 2000; // in miliseconds
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            isonline();
        }

        public async void isonline()
        {
            //System.Windows.MessageBox.Show("TINER FIRED");
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            client.DefaultRequestHeaders.Accept.Add(
           new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync(urlParameters).Result;
            var dataObjects = response.Content.ReadAsAsync<Terminal_payment>().Result;
            if (dataObjects.Send == "0")
            {
                Amount = dataObjects.Amount.ToString();
                await SendTranscaction();

            }
        }

        public System.Windows.Controls.TextBox AmountTextBox;

        private ICommand _printFinalBalanceCommand;
        public ICommand PrintFinalBalanceCommand
        {
            get
            {
                return _printFinalBalanceCommand ?? (_printFinalBalanceCommand = new RelayCommand(
                   async x =>
                   {
                       await SendPrintFinalBalance();
                   }));
            }
        }

        private ICommand _backCommand;
        public ICommand BackCommand
        {
            get
            {
                return _backCommand ?? (_backCommand = new RelayCommand(
                   x =>
                   {
                       BackAmount();
                   }));
            }
        }

        private ICommand _saveSettings;
        public ICommand SaveSettingsCommand
        {
            get
            {
                return _saveSettings ?? (_saveSettings = new RelayCommand(
                   x =>
                   {
                       SaveSettings();
                   }));
            }
        }

        private ICommand _clearCommand;
        public ICommand ClearCommand
        {
            get
            {
                return _clearCommand ?? (_clearCommand = new RelayCommand(
                   x =>
                   {
                       Amount = "";
                       ResultTerminal = "";
                       SetFocus();
                   }));
            }
        }

        private ICommand _openFinalBalanceDirectoryCommand;
        public ICommand OpenFinalBalanceDirectoryCommand
        {
            get
            {
                return _openFinalBalanceDirectoryCommand ?? (_openFinalBalanceDirectoryCommand = new RelayCommand(
                   x =>
                   {
                       Process.Start("explorer.exe", _finalBalanceWorkPath);
                   }));
            }
        }

        private ICommand _pingCommand;
        public ICommand PingCommand
        {
            get
            {
                return _pingCommand ?? (_pingCommand = new RelayCommand(
                   async x =>
                   {
                       await SendPing();
                   }));
            }
        }

        private ICommand _clearPrintHistoryommand;
        public ICommand ClearPrintHistoryommand
        {
            get
            {
                return _clearPrintHistoryommand ?? (_clearPrintHistoryommand = new RelayCommand(
                   async x =>
                   {
                       DisplayOrPrint = "";
                   }));
            }
        }

        private ICommand _sendTransactionCommand;


        public ICommand SendTransactionCommand
        {
            get
            {
                return _sendTransactionCommand ?? (_sendTransactionCommand = new RelayCommand(
                   async x =>
                   {
                       await SendTranscaction();
                       SetFocus();
                   }));
            }
        }
        private ICommand _abortTransactionCommand;


        public ICommand AbortTransactionCommand
        {
            get
            {
                return _abortTransactionCommand ?? (_abortTransactionCommand = new RelayCommand(
                   async x =>
                   {
                       await SendAbort();
                       SetFocus();
                   }));
            }
        }

        private ICommand _numPad0Command;
        public ICommand NumPad0Command
        {
            get
            {
                return _numPad0Command ?? (_numPad0Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}0";
                   }));
            }
        }

        private ICommand _numPad1Command;
        public ICommand NumPad1Command
        {
            get
            {
                return _numPad1Command ?? (_numPad1Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}1";
                   }));
            }
        }
        private ICommand _numPad2Command;
        public ICommand NumPad2Command
        {
            get
            {
                return _numPad2Command ?? (_numPad2Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}2";
                   }));
            }
        }
        private ICommand _numPad3Command;
        public ICommand NumPad3Command
        {
            get
            {
                return _numPad3Command ?? (_numPad3Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}3";
                   }));
            }
        }
        private ICommand _numPad4Command;
        public ICommand NumPad4Command
        {
            get
            {
                return _numPad4Command ?? (_numPad4Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}4";
                   }));
            }
        }
        private ICommand _numPad5Command;
        public ICommand NumPad5Command
        {
            get
            {
                return _numPad5Command ?? (_numPad5Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}5";
                   }));
            }
        }
        private ICommand _numPad6Command;
        public ICommand NumPad6Command
        {
            get
            {
                return _numPad6Command ?? (_numPad6Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}6";
                   }));
            }
        }
        private ICommand _numPad7Command;
        public ICommand NumPad7Command
        {
            get
            {
                return _numPad7Command ?? (_numPad7Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}7";
                   }));
            }
        }
        private ICommand _numPad8Command;
        public ICommand NumPad8Command
        {
            get
            {
                return _numPad8Command ?? (_numPad8Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}8";
                   }));
            }
        }
        private ICommand _numPad9Command;
        public ICommand NumPad9Command
        {
            get
            {
                return _numPad9Command ?? (_numPad9Command = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}9";
                   }));
            }
        }

        private ICommand _numPadDotCommand;
        public ICommand NumPadDotCommand
        {
            get
            {
                return _numPadDotCommand ?? (_numPadDotCommand = new RelayCommand(
                   async x =>
                   {
                       Amount = $"{Amount}.";
                   }));
            }
        }



        private bool _progressActive;
        public bool ProgressActive
        {
            get { return _progressActive; }
            set
            {
                _progressActive = value;
                NotifyPropertyChanged();
            }
        }



        private string _POSID;
        public string POSID
        {
            get { return _POSID; }
            set
            {
                _POSID = value;
                NotifyPropertyChanged();
            }
        }

        private int _cursorPosition;
        public int CursorPosition
        {
            get { return _cursorPosition; }
            set
            {
                _cursorPosition = value;
                NotifyPropertyChanged();
            }
        }

        private string _displayOrPrint;
        public string DisplayOrPrint
        {
            get { return _displayOrPrint; }
            set
            {
                _displayOrPrint = value;
                NotifyPropertyChanged();
            }
        }

        private string _widthOfWindow;
        public string WidthOfWindow
        {
            get { return _widthOfWindow; }
            set
            {
                _widthOfWindow = value;
                NotifyPropertyChanged();
            }
        }

        private string _heightOfWindow;
        public string HeightOfWindow
        {
            get { return _heightOfWindow; }
            set
            {
                _heightOfWindow = value;
                NotifyPropertyChanged();
            }
        }

        private string _ipOrHostname;
        public string IpOrHostname
        {
            get { return _ipOrHostname; }
            set
            {
                _ipOrHostname = value;
                NotifyPropertyChanged();
            }
        }



        private string _finalBalanceResult;
        public string FinalBalanceResult
        {
            get { return _finalBalanceResult; }
            set
            {
                _finalBalanceResult = value;
                NotifyPropertyChanged();
            }
        }

        private string _port;
        public string Port
        {
            get { return _port; }
            set
            {
                _port = value;
                NotifyPropertyChanged();
            }
        }
        private string _timeOut;
        public string TimeOut
        {
            get { return _timeOut; }
            set
            {
                _timeOut = value;
                NotifyPropertyChanged();
            }
        }
        private string _error;
        public string Error
        {
            get { return _error; }
            set
            {
                _error = value;
                NotifyPropertyChanged();
            }
        }
        private string _display;
        public string Display
        {
            get { return _display; }
            set
            {
                _display = value;
                NotifyPropertyChanged();
            }
        }

        private string _resultTerminal;
        public string ResultTerminal
        {
            get { return _resultTerminal; }
            set
            {
                _resultTerminal = value;
                NotifyPropertyChanged();
            }
        }

        private string _amount;
        public string Amount
        {
            get { return _amount; }
            set
            {
                _amount = value;

                NotifyPropertyChanged();
                SetFocus();
            }
        }

        private void SetFocus()
        {
            AmountTextBox.Focus();
            AmountTextBox.Select(_amount.Length, 0);
        }
        private bool _canSendTransaction;
        public bool CanSendTransaction
        {
            get { return _canSendTransaction; }
            set
            {
                _canSendTransaction = value;
                NotifyPropertyChanged();
            }
        }

        private bool _canPrintFinalBalance;
        public bool CanPrintFinalBalance
        {
            get { return _canPrintFinalBalance; }
            set
            {
                _canPrintFinalBalance = value;
                NotifyPropertyChanged();
            }
        }

        private bool _canPing;
        public bool CanPing
        {
            get { return _canPing; }
            set
            {
                _canPing = value;
                NotifyPropertyChanged();
            }
        }
        private bool _canEnter;
        public bool CanEnter
        {
            get { return _canEnter; }
            set
            {
                _canEnter = value;
                NotifyPropertyChanged();
            }
        }
        private string _resultFullMessage;

        public string ResultFullMessage
        {
            get { return _resultFullMessage; }
            set
            {
                _resultFullMessage = value;
                NotifyPropertyChanged();
            }
        }

        private string _sendMessage;
        public string SendMessage
        {
            get { return _sendMessage; }
            set
            {
                _sendMessage = value;
                NotifyPropertyChanged();
            }
        }

        private async Task SendPrintFinalBalance()
        {
            BlockGUIForTransaction();
            _isFinalBalancePrinting = true;
            FinalBalanceResult = "";
            SendMessage = await _payWorldTerminal.SendGetFinalBalance(POSID);
            EnableGUIForTransaction();
        }

        private void BackAmount()
        {
            if (!String.IsNullOrEmpty(_amount))
                Amount = _amount.Substring(0, _amount.Length - 1);
        }

        public async Task SendAbort()
        {
            try
            {
                BlockGUIForTransaction();
                if (_lastMessageConfirmationRequest)
                {
                    SendMessage = await _payWorldTerminal.SendConfirmationResponseNegative();
                    _lastMessageConfirmationRequest = false;
                }
                else
                {
                    SendMessage = await _payWorldTerminal.SendAbort();
                }
                EnableGUIForTransaction();
            }
            catch (Exception ex)
            {
                WriteError(ex);
                EnableGUIForTransaction();
            }
        }

        public async Task SendTranscaction()
        {
            try
            {

                if (CanSendTransaction)
                {
                    BlockGUIForTransaction();
                    if (_lastMessageConfirmationRequest)
                    {
                        SendMessage = await _payWorldTerminal.SendConfirmationResponsePositive();
                        _lastMessageConfirmationRequest = false;
                    }
                    else
                    {
                        decimal amountDecimal = 0;
                        try
                        {
                            ResultTerminal = "";
                            amountDecimal = Convert.ToDecimal(Amount.Replace(".", ","));
                            amountDecimal = amountDecimal * 100;
                        }
                        catch (Exception)
                        {
                            ResultTerminal = "Invalid amount...";
                            EnableGUIForTransaction();
                            return;
                        }
                        // CurrencyType.Item978 = EURO

                        FinancialTrxRequest request = new FinancialTrxRequest
                        {
                            posId = POSID
                        };
                        // trx info - receive notifications - see topic 9.1.1 trxInfo bitmask
                        Byte[] bytes = new Byte[3] { 0, 0, 3 };
                        request.trxInfo = bytes;
                        request.trxData = new TransactionData() { amount = Convert.ToUInt64(amountDecimal), currency = PayWorld.API.Messages.Pos.CurrencyType.Item978, transactionType = TransactionType.Purchase };
                        SendMessage = request.PosXmlSerialize();
                        ResultFullMessage = await _payWorldTerminal.SendGenericMessage(SendMessage);
                    }
                }
                EnableGUIForTransaction();

            }
            catch (Exception ex)
            {
                WriteError(ex);
                EnableGUIForTransaction();
            }
        }

        public async Task SendPing()
        {
            try
            {
                BlockGUIForTransaction();
                SendMessage = await _payWorldTerminal.SendPingPong();
                EnableGUIForTransaction();
            }
            catch (Exception ex)
            {
                WriteError(ex);
                EnableGUIForTransaction();
            }
        }

        private async Task SendFinalBalance()
        {
            try
            {
                BlockGUIForTransaction();
                await _payWorldTerminal.SendGetFinalBalance(POSID);
                EnableGUIForTransaction();

            }
            catch (Exception ex)
            {
                WriteError(ex);
                EnableGUIForTransaction();
            }
        }


        private void WriteError(Exception ex)
        {
            ResultTerminal = "Error occured: see -> Settings - General exceptions for more info";
            Error = $"{ex.Message}{Environment.NewLine}{ex.StackTrace}";
            Log.AddError(ex);
        }

        private void LoadSettings()
        {
            WidthOfWindow = INIDataHelper.Instance["POS"]["screenwidth"];
            HeightOfWindow = INIDataHelper.Instance["POS"]["screenheight"];
            IpOrHostname = INIDataHelper.Instance["POS"]["ip"];
            Port = INIDataHelper.Instance["POS"]["port"];
            TimeOut = INIDataHelper.Instance["POS"]["timeout"];
            POSID = INIDataHelper.Instance["POS"]["posid"];

        }

        private void SaveSettings()
        {
            try
            {
                INIDataHelper.Instance["POS"]["screenwidth"] = WidthOfWindow;
                INIDataHelper.Instance["POS"]["screenheight"] = HeightOfWindow;
                INIDataHelper.Instance["POS"]["ip"] = IpOrHostname;
                INIDataHelper.Instance["POS"]["port"] = Port;
                INIDataHelper.Instance["POS"]["timeout"] = TimeOut;
                INIDataHelper.Instance["POS"]["posid"] = POSID;

                INIDataHelper.SaveIniFile();

                _payWorldTerminal = null;
                _payWorldTerminal = new Terminal();
                _payWorldTerminal.Init(IpOrHostname, Convert.ToInt32(Port), Convert.ToInt32(TimeOut) * 1000);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void SubscribeToEvents()
        {
            if (_payWorldTerminal != null)
            {
                _payWorldTerminal.OnConfirmationRequestReceived += _payWorldTerminal_OnConfirmationRequestReceived;
                _payWorldTerminal.OnDisplayNotificationCompleted += _payWorldTerminal_OnDisplayNotificationCompleted;
                _payWorldTerminal.OnErrorNotificationCompleted += _payWorldTerminal_OnErrorNotificationCompleted;
                _payWorldTerminal.OnPingPongCompleted += _payWorldTerminal_OnPingPongCompleted;
                _payWorldTerminal.OnPrinterNotificationCompleted += _payWorldTerminal_OnPrinterNotificationCompleted;
                _payWorldTerminal.OnFinancialTrxResponseCompleted += _payWorldTerminal_OnFinancialTrxResponseCompleted;
                _payWorldTerminal.OnBeFinalBalanceResponseCompleted += _payWorldTerminal_OnBeFinalBalanceResponseCompleted;
            }
        }

        private void _payWorldTerminal_OnBeFinalBalanceResponseCompleted()
        {
            _isFinalBalancePrinting = false;
        }

        private void _payWorldTerminal_OnFinancialTrxResponseCompleted()
        {
            // reset amount
            Amount = "";
            ResultFullMessage = _payWorldTerminal.GetFinancialTrxResponse().PosXmlSerialize();
        }

        private void _payWorldTerminal_OnPrinterNotificationCompleted()
        {
            string printerResult = _payWorldTerminal.GetPrinterNotificationAsString();

            if (_isFinalBalancePrinting)
            {
                File.WriteAllText($@"{_finalBalanceWorkPath}\finalbalanceprintedon{DateTime.Now.ToString("yyyyMMddHHmmssfff")}.txt", printerResult, new UTF8Encoding(false));
                FinalBalanceResult = printerResult + FinalBalanceResult;
            }
            else
            {
                DisplayOrPrint = printerResult + DisplayOrPrint;
            }
        }

        private void _payWorldTerminal_OnPingPongCompleted()
        {
            PingResponse response = _payWorldTerminal.GetPingResponse();
            ResultFullMessage = response.PosXmlSerialize();
        }

        private void _payWorldTerminal_OnErrorNotificationCompleted()
        {
            _isFinalBalancePrinting = false;
            if (_hasAbortErrorOnStartupHappend < 2)
            {
                _hasAbortErrorOnStartupHappend++;
                ResultTerminal = "";
            }
            else
            {
                ResultTerminal = _payWorldTerminal.GetErrorNotificationAsString();
            }
            Log.AddErrorMessage(_payWorldTerminal.GetErrorNotificationAsString());
            EnableGUIForTransaction();
        }

        private void _payWorldTerminal_OnDisplayNotificationCompleted()
        {
            DisplayNotification notification = _payWorldTerminal.GetDisplayNotification();
            string result = $"{notification.display.line.First()} - {notification.displayType}";
            foreach (string line in notification.display.line)
            {
                result = line + Environment.NewLine;
            }

            Display = $"Logic performed on response from pay terminal: {result} {Environment.NewLine}------------------------------{Environment.NewLine}Original message:{Environment.NewLine}------------------------------{Environment.NewLine}{notification.PosXmlSerialize()}";
            if (!String.IsNullOrEmpty(result))
                ResultTerminal = $"{result}";



        }

        private void _payWorldTerminal_OnConfirmationRequestReceived()
        {
            ResultTerminal = _payWorldTerminal.GetConfirmationRequestAsString();
            _lastMessageConfirmationRequest = true;
        }

        private void UnSubscribeToEvents()
        {
            if (_payWorldTerminal != null)
            {
                _payWorldTerminal.OnConfirmationRequestReceived -= _payWorldTerminal_OnConfirmationRequestReceived;
                _payWorldTerminal.OnDisplayNotificationCompleted -= _payWorldTerminal_OnDisplayNotificationCompleted;
                _payWorldTerminal.OnErrorNotificationCompleted -= _payWorldTerminal_OnErrorNotificationCompleted;
                _payWorldTerminal.OnPingPongCompleted -= _payWorldTerminal_OnPingPongCompleted;
                _payWorldTerminal.OnPrinterNotificationCompleted -= _payWorldTerminal_OnPrinterNotificationCompleted;
                _payWorldTerminal.OnFinancialTrxResponseCompleted -= _payWorldTerminal_OnFinancialTrxResponseCompleted;
                _payWorldTerminal.OnBeFinalBalanceResponseCompleted -= _payWorldTerminal_OnBeFinalBalanceResponseCompleted;
            }
        }

        private void BlockGUIForTransaction()
        {
            ResultFullMessage = "";
            Error = "";
            Display = "";
            ResultTerminal = "";
            CanSendTransaction = false;
            CanPing = false;
            CanEnter = false;
            CanPrintFinalBalance = false;
            ProgressActive = true;
        }
        private void EnableGUIForTransaction()
        {
            CanSendTransaction = true;
            CanPing = true;
            CanEnter = true;
            CanPrintFinalBalance = true;
            ProgressActive = false;
        }

        ~MainWindowViewmodel()
        {
            UnSubscribeToEvents();
            _payWorldTerminal = null;

        }
    }
}
