﻿using IniParser;
using IniParser.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayWorld.Helpers
{

    public class INIDataHelper
    {
        private static string _settingsDir = $@"{Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)}\POSPayWorld";
        private static string _settingsFile = _settingsDir + @"\settings.ini";
        private static IniData _dataINI;
        private static FileIniDataParser _parser = new FileIniDataParser();

        public static IniData Instance
        {
            get
            {
                if (_dataINI == null)
                {
                    Init();
                }

                return _dataINI;
            }
        }
        private static IniData Init()
        {
            Directory.CreateDirectory(_settingsDir);
            if (!File.Exists(_settingsFile))
            {
                string content = "";
                File.WriteAllText(_settingsFile, content);

                var dataini = new IniData();
                dataini.Sections.Add(new SectionData("POS"));
                dataini["POS"].AddKey(new KeyData("screenwidth"));
                dataini["POS"].AddKey(new KeyData("screenheight"));
                dataini["POS"].AddKey(new KeyData("ip"));
                dataini["POS"].AddKey(new KeyData("port"));
                dataini["POS"].AddKey(new KeyData("timeout"));
                dataini["POS"]["screenwidth"] = "800";
                dataini["POS"]["screenheight"] = "500";
                dataini["POS"]["ip"] = "192.168.0.100";
                dataini["POS"]["port"] = "50000";
                dataini["POS"]["timeout"] = "60";
                _dataINI = dataini;
                SaveIniFile();
            }
            else
            {
                _dataINI = _parser.ReadFile(_settingsFile);

            }
            return _dataINI;
        }

        public static void SaveIniFile()
        {
            _parser.WriteFile(_settingsFile, _dataINI);       

        }
    }
}
