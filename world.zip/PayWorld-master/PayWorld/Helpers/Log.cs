﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayWorld.Helpers
{
    public static class Log
    {
        private static string _workPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\Logs";
        private static string _logFile;
        private static FileInfo logFile;
        public static void Init()
        {
            if (!Directory.Exists(_workPath))
                Directory.CreateDirectory(_workPath);
            _logFile = $@"{_workPath}\log.txt";

            if (!File.Exists(_logFile))
            {
                File.AppendAllText(_logFile, "");
            }
            foreach (var file in Directory.GetFiles(_workPath))
            {
                if (new FileInfo(file).CreationTime < DateTime.Now.AddDays(-30))
                {
                    File.Delete(file);
                }
            }

            logFile = new FileInfo(_logFile);
        }
        public static void AddError(Exception ex)
        {
            string message = "";
            message = ex.Message;
            message += Environment.NewLine + ex.StackTrace;
            if (ex.InnerException != null)
            {
                message += Environment.NewLine + ex.InnerException.Message;
                message += Environment.NewLine + ex.InnerException.StackTrace;
            }

            AddToLog(message, "ERROR");
        }
        public static void AddErrorMessage(string message)
        {
            AddToLog(message, "ERROR");
        }
        public static void Add(string message)
        {
            AddToLog(message, "INFO");
        }

        private static void AddToLog(string message, string type)
        {
            string prefix = $"{DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff")} - {type} ";
            string line = prefix + message + Environment.NewLine;
            if (logFile.Length > 2000000)
            {
                File.Copy(_logFile, _logFile.Replace("log.txt", $"log{DateTime.Now.ToString("yyyyMMddHHmmss.fff")}.txt"));
            }
            File.AppendAllText(_logFile, line);
        }
    }
}
