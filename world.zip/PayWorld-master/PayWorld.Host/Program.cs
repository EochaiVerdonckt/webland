﻿using System;

namespace PayWorld.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World! This is the PayWorld cross platform console.");

            // Make your own implementation ... 
            
        }
    }
}
