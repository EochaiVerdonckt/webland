﻿namespace com.vibbek.client.pos
{
	using com.vibbek.client.pos.message;

	/// <summary>
	/// This is the interface required for objects to be informed about incoming Notifications
	/// from the VCS.
	/// </summary>
	public interface IPOSNotificationListener
	{

		/// <summary>
		/// Called when a <seealso cref="POSDisplayNotification"/> is received from the VCS.
		/// </summary>
		/// <param name="notification">
		///            The received DisplayNotification. </param>
		void onDisplayNotification(POSDisplayNotification notification);

		/// <summary>
		/// Called when a <seealso cref="POSPrinterNotification"/> is received from the VCS.
		/// </summary>
		/// <param name="notification">
		///            The received PrinterNotification. </param>
		void onPrinterNotification(POSPrinterNotification notification);

		/// <summary>
		/// Called when the client starts a new request.
		/// </summary>
		void onNewRequestStarted();

		/// <summary>
		/// Called when the client receives the result/final response.
		/// </summary>
		void onResponseArrived();

	}

}