﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instances of this class represent a request to the VCS to
	/// perform a transmission to all acquirers.
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "beTransmissionRequest") public class POSTransmissionSubmissionRequest extends AbstractPOSRequest
	public class POSTransmissionSubmissionRequest : AbstractPOSRequest
	{

	}

}