﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Message send if an error occurs on the server and a response which
	/// fits to the request cannot be send.
	/// 
	/// @author aflaegel
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "errorNotification") public class POSErrorNotification implements IPOSResponse
	public class POSErrorNotification : IPOSResponse
	{

		private string errorText;
		private string errorCode;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "errorText", required = false) public String getErrorText()
		public virtual string ErrorText
		{
			get
			{
				return this.errorText;
			}
			set
			{
				this.errorText = value;
			}
		}



//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "errorCode", required = false) public String getErrorCode()
		public virtual string ErrorCode
		{
			get
			{
				return this.errorCode;
			}
			set
			{
				this.errorCode = value;
			}
		}


	}

}