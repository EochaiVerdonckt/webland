﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Response message of a <seealso cref="POSReversalRequest"/> message.
	/// 
	/// @author aflaegel
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "reversalResponse") public class POSReversalResponse implements IPOSResponse
	public class POSReversalResponse : IPOSResponse
	{

	 // general response fields
		private string amountRev;
		private string amountRevCurr;

		private string acquirerId;
		private string cardAppId;
		private string cardAppLabel;
		private string cardExpDate;
		private string cardNumber;
		private string cardSeqNumber;
		private string transactionTime;

		// ep2 response fields
		private string ep2TrmId;
		private string ep2TrxSeqCnt;
		private string ep2TrxSeqCntOrigTrx;
		private string ep2TrxTypeExtOrigTrx;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "amountRev") public String getAmountRev()
		public virtual string AmountRev
		{
			get
			{
				return amountRev;
			}
			set
			{
				this.amountRev = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "amountRevCurr") public String getAmountRevCurr()
		public virtual string AmountRevCurr
		{
			get
			{
				return amountRevCurr;
			}
			set
			{
				this.amountRevCurr = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "transactionTime") public String getTransactionTime()
		public virtual string TransactionTime
		{
			get
			{
				return this.transactionTime;
			}
			set
			{
				this.transactionTime = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "acquirerId") public String getAcquirerId()
		public virtual string AcquirerId
		{
			get
			{
				return this.acquirerId;
			}
			set
			{
				this.acquirerId = value;
			}
		}


		/// <returns>  application masked PAN.  </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardNumber") public String getCardNumber()
		public virtual string CardNumber
		{
			get
			{
				return this.cardNumber;
			}
			set
			{
				this.cardNumber = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardAppLabel") public String getCardAppLabel()
		public virtual string CardAppLabel
		{
			get
			{
				return this.cardAppLabel;
			}
			set
			{
				this.cardAppLabel = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardAppId") public String getCardAppId()
		public virtual string CardAppId
		{
			get
			{
				return this.cardAppId;
			}
			set
			{
				this.cardAppId = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardExpDate") public String getCardExpDate()
		public virtual string CardExpDate
		{
			get
			{
				return this.cardExpDate;
			}
			set
			{
				this.cardExpDate = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardSeqNumber") public String getCardSeqNumber()
		public virtual string CardSeqNumber
		{
			get
			{
				return this.cardSeqNumber;
			}
			set
			{
				this.cardSeqNumber = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2TrmId") public String getEp2TrmId()
		public virtual string Ep2TrmId
		{
			get
			{
				return this.ep2TrmId;
			}
			set
			{
				this.ep2TrmId = value;
			}
		}


		/// <summary>
		/// Returns the transaction sequence counter of the processed reversal.
		/// </summary>
		/// <returns>  ep2 transaction sequence counter </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2TrxSeqCnt") public String getEp2TrxSeqCnt()
		public virtual string Ep2TrxSeqCnt
		{
			get
			{
				return this.ep2TrxSeqCnt;
			}
			set
			{
				this.ep2TrxSeqCnt = value;
			}
		}


		/// <summary>
		/// Returns the transaction sequence counter of the reversed transaction.
		/// </summary>
		/// <returns>  ep2 transaction sequence counter </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2TrxSeqCntOrigTrx") public String getEp2TrxSeqCntOrigTrx()
		public virtual string Ep2TrxSeqCntOrigTrx
		{
			get
			{
				return this.ep2TrxSeqCntOrigTrx;
			}
			set
			{
				this.ep2TrxSeqCntOrigTrx = value;
			}
		}


		/// <summary>
		/// Returns the transaction type extension of the reversed transaction.
		/// </summary>
		/// <returns>  ep2 transaction type extension </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ep2TrxTypeExtOrigTrx") public String getEp2TrxTypeExtOrigTrx()
		public virtual string Ep2TrxTypeExtOrigTrx
		{
			get
			{
				return this.ep2TrxTypeExtOrigTrx;
			}
			set
			{
				this.ep2TrxTypeExtOrigTrx = value;
			}
		}


	}

}