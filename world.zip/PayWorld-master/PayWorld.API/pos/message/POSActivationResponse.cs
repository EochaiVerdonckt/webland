﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instaces of this class represent responses of the Vibbek CS to
	/// POSActivationRequests.
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "activationResponse") public class POSActivationResponse implements IPOSResponse
	public class POSActivationResponse : IPOSResponse
	{

	}

}