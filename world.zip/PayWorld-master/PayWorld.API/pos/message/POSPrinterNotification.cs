﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// This class is the printer notification message. The VPJ sends the printer notification to the PoS.
	/// 
	/// @author mkitschke
	/// 
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "printerNotification", namespace = "http://www.vibbek.com/device") public class POSPrinterNotification implements IPOSMessage
	public class POSPrinterNotification : IPOSMessage
	{

		private POSMerchantReceipt merchantReceipt;
		private string cardholderReceipt;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "merchantReceipt") public POSMerchantReceipt getMerchantReceipt()
		public virtual POSMerchantReceipt MerchantReceipt
		{
			get
			{
				return merchantReceipt;
			}
			set
			{
				this.merchantReceipt = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cardholderReceipt") public String getCardholderReceipt()
		public virtual string CardholderReceipt
		{
			get
			{
				return cardholderReceipt;
			}
			set
			{
				this.cardholderReceipt = value;
			}
		}

	}

}