﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Request message to test the connection to the terminal server.
	/// 
	/// @author aflaegel
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "pingRequest") public class POSPingRequest implements IPOSRequest
	public class POSPingRequest : IPOSRequest
	{

		private string posId;

		public virtual string PosId
		{
			set
			{
				this.posId = value;
			}
			get
			{
				return this.posId;
			}
		}

	}

}