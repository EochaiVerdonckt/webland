﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// The PoS sends the confirmation response to the VPJ. This message contains the selection of the user.
	/// 
	/// @author mkitschke
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "confirmationResponse", namespace = "http://www.vibbek.com/device") public class POSConfirmationResponse implements IPOSMessage
	public class POSConfirmationResponse : IPOSMessage
	{

		private string result;

		/// 
		public POSConfirmationResponse()
		{
		}

		/// <param name="result"> allowed values: "0", "1" </param>
//JAVA TO C# CONVERTER WARNING: 'final' parameters are ignored unless the option to convert to C# 7.2 'in' parameters is selected:
//ORIGINAL LINE: public POSConfirmationResponse(final String result)
		public POSConfirmationResponse(string result)
		{
			this.result = result;
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "result") public String getResult()
		public virtual string Result
		{
			get
			{
				return result;
			}
			set
			{
				this.result = value;
			}
		}

	}

}