﻿using System.Collections.Generic;

namespace com.vibbek.client.pos.message
{

	using IconIdType = com.vibbek.util.vcs.IconIdType;

	/// <summary>
	/// Describes the XML displays elements.
	/// </summary>
	public class POSDisplayItem
	{

		private string key;

		private IList<string> lines = new List<string>();

		private IconIdType iconIdType;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "line") public List<String> getLines()
		public virtual IList<string> Lines
		{
			get
			{
				return this.lines;
			}
			set
			{
				this.lines = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "key") public String getKey()
		public virtual string Key
		{
			get
			{
				return this.key;
			}
			set
			{
				this.key = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "iconId") public com.vibbek.util.vcs.IconIdType getIconIdType()
		public virtual IconIdType IconIdType
		{
			get
			{
				return this.iconIdType;
			}
			set
			{
				this.iconIdType = value;
			}
		}

	}

}