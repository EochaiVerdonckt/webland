﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Response to the <seealso cref="POSDeactivationRequest"/> message.
	/// 
	/// @author mdraeger
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "deactivationResponse") public class POSDeactivationResponse implements IPOSResponse
	public class POSDeactivationResponse : IPOSResponse
	{

	}

}