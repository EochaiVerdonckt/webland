﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instances of this class represent a request to trigger a coupon id check, requested by the POS.
	/// 
	/// @author dbuck
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "checkCouponIdRequest") public class POSCheckCouponIdRequest extends AbstractPOSRequest
	public class POSCheckCouponIdRequest : AbstractPOSRequest
	{

		private int? couponId = null;

		/// <summary>
		/// Provides the coupon id to check.
		/// </summary>
		/// <returns> the coupon id to check. </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "couponId") public System.Nullable<int> getCouponId()
		public virtual int? CouponId
		{
			get
			{
				return this.couponId;
			}
			set
			{
				this.couponId = value;
			}
		}


	}

}