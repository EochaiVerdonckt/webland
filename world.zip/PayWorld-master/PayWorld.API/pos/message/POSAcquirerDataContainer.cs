﻿using System.Collections.Generic;

namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Container for acquirer configuration data.
	/// 
	/// @author aguenther
	/// </summary>
	public class POSAcquirerDataContainer
	{

		private string acquirerId;
		private IList<POSTerminalApplicationConfigDataContainer> terminalApplicationConfigDataList;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "acquirerId", required = false) public String getAcquirerId()
		public virtual string AcquirerId
		{
			get
			{
				return acquirerId;
			}
			set
			{
				this.acquirerId = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElementWrapper(name = "terminalApplicationConfigDataList", required = false) @XmlElement(name = "terminalApplicationConfigData", required = false) public java.util.List<POSTerminalApplicationConfigDataContainer> getTerminalApplicationConfigDataList()
		public virtual IList<POSTerminalApplicationConfigDataContainer> TerminalApplicationConfigDataList
		{
			get
			{
				return terminalApplicationConfigDataList;
			}
			set
			{
				this.terminalApplicationConfigDataList = value;
			}
		}

	}

}