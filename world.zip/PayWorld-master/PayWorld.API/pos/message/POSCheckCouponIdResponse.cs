﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Response message of a <seealso cref="POSCheckCouponIdRequest"/> message.
	/// 
	/// @author dbuck
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "checkCouponIdResponse") public class POSCheckCouponIdResponse implements IPOSResponse
	public class POSCheckCouponIdResponse : IPOSResponse
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlEnum(String.class) public enum CheckCouponIdResultType
		public enum CheckCouponIdResultType
		{
			OK,
			FAILED
		}

		private CheckCouponIdResultType result;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "result") public CheckCouponIdResultType getResult()
		public virtual CheckCouponIdResultType Result
		{
			get
			{
				return this.result;
			}
			set
			{
				this.result = value;
			}
		}


	}

}