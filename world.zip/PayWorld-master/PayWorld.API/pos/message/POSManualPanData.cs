﻿using System;

namespace com.vibbek.client.pos.message
{

	using MessageFormatHelper = com.vibbek.util.misc.MessageFormatHelper;

	/// <summary>
	/// Implements the manually PAN entry data container.
	/// 
	/// @author mdraeger
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType public class POSManualPanData implements java.io.Serializable
	[Serializable]
	public class POSManualPanData
	{

		private const long serialVersionUID = 1L;

		private string applicationExpirationDate;
		private string primaryAccountNumber;
		private string cardVerificationCode2;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "PAN") public String getPrimaryAccountNumber()
		public virtual string PrimaryAccountNumber
		{
			get
			{
				return this.primaryAccountNumber;
			}
			set
			{
				this.primaryAccountNumber = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "applicationExpirationDate") public String getApplicationExpirationDate()
		public virtual string ApplicationExpirationDate
		{
			get
			{
				return this.applicationExpirationDate;
			}
			set
			{
				this.applicationExpirationDate = MessageFormatHelper.convert4To6DigitDate(value);
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "cvc2") public String getCardVerificationCode2()
		public virtual string CardVerificationCode2
		{
			get
			{
				return this.cardVerificationCode2;
			}
			set
			{
				this.cardVerificationCode2 = value;
			}
		}

	}

}