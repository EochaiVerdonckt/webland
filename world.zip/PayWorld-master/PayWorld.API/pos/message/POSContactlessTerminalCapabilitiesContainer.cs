﻿using System;

namespace com.vibbek.client.pos.message
{

	using ByteArray = com.vibbek.util.misc.ByteArray;

	/// <summary>
	/// Container for contactless terminal capabilities per kernel ID.
	/// 
	/// @author aguenther
	/// </summary>
	public class POSContactlessTerminalCapabilitiesContainer
	{

		private int? kernelId;
		private sbyte[] terminalCapabilities;
		private sbyte[] additionalTerminalCapabilities;
		private string dataExchangeFlag;
		private string kernelVersion;
		private string trxMode;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ctlessKnlID") public System.Nullable<int> getKernelId()
		public virtual int? KernelId
		{
			get
			{
				return kernelId;
			}
			set
			{
				this.kernelId = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Deprecated @XmlElement(name = "ctlessTrmCap") public byte[] getTerminalCapabilities()
		[Obsolete]
		public virtual sbyte[] TerminalCapabilities
		{
			get
			{
				return ByteArray.copy(terminalCapabilities);
			}
			set
			{
				this.terminalCapabilities = ByteArray.copy(value);
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ctlessAddTrmCap") public byte[] getAdditionalTerminalCapabilities()
		public virtual sbyte[] AdditionalTerminalCapabilities
		{
			get
			{
				return ByteArray.copy(additionalTerminalCapabilities);
			}
			set
			{
				this.additionalTerminalCapabilities = ByteArray.copy(value);
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ctlessDataExchangeFlag") public String getDataExchangeFlag()
		public virtual string DataExchangeFlag
		{
			get
			{
				return dataExchangeFlag;
			}
			set
			{
				this.dataExchangeFlag = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ctlessKnlVers") public String getKernelVersion()
		public virtual string KernelVersion
		{
			get
			{
				return this.kernelVersion;
			}
			set
			{
				this.kernelVersion = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "ctlessTrxMode") public String getTransactionMode()
		public virtual string TransactionMode
		{
			get
			{
				return this.trxMode;
			}
			set
			{
				this.trxMode = value;
			}
		}

	}

}