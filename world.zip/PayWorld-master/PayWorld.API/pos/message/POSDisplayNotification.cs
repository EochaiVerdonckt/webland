﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// This message is received from the VCS. It contains text to display on
	/// the POS Attendant Display.
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "displayNotification", namespace = "http://www.vibbek.com/device") public class POSDisplayNotification implements IPOSMessage
	public class POSDisplayNotification : IPOSMessage
	{

		private POSDisplayItem display = new POSDisplayItem();
		private POSDisplayType displayType;
		private int? minDisplayTime;

		/// <summary>
		/// Returns the list of display lines.
		/// </summary>
		/// <returns> the list of display lines. </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "display") public POSDisplayItem getDisplay()
		public virtual POSDisplayItem Display
		{
			get
			{
				return this.display;
			}
			set
			{
				this.display = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlAttribute(required = true) public POSDisplayType getDisplayType()
		public virtual POSDisplayType DisplayType
		{
			get
			{
				return this.displayType;
			}
			set
			{
				this.displayType = value;
			}
		}


		/// <summary>
		/// Gets the minimum time to display the text, in seconds. </summary>
		/// <returns> The minimum time to display the text </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "minDisplayTime") public System.Nullable<int> getMinDisplayTime()
		public virtual int? MinDisplayTime
		{
			get
			{
				return this.minDisplayTime;
			}
			set
			{
				this.minDisplayTime = value;
			}
		}


	}

}