﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// This class represents a requests to initialization the terminal.
	/// corresponding to this clientId.
	/// 
	/// @author aflaegel
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "siInitRequest") public class POSInitRequest extends AbstractPOSRequest
	public class POSInitRequest : AbstractPOSRequest
	{

	}

}