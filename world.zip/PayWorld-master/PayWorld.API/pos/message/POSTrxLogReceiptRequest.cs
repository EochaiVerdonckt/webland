﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instances of this class represent a request to trigger a transaction log receipt, requested by the POS.
	/// 
	/// @author mdraeger
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "trxLogReceiptRequest") public class POSTrxLogReceiptRequest extends AbstractPOSRequest
	public class POSTrxLogReceiptRequest : AbstractPOSRequest
	{

		private int? numberOfTrx = null;

		/// <summary>
		/// Provides the number of transaction since the last final balance, to be printed.
		/// </summary>
		/// <returns> number of trx or <code>null</code> to print all transaction since last final balance. </returns>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "numberOfTrx") public System.Nullable<int> getNumberOfTrx()
		public virtual int? NumberOfTrx
		{
			get
			{
				return this.numberOfTrx;
			}
			set
			{
				this.numberOfTrx = value;
			}
		}


	}

}