﻿namespace com.vibbek.client.pos.message
{
	/// <summary>
	/// Instances of this class create all kinds of Request-objects that
	/// can be used to send to the Vibbek CS via a VPJ implementation
	/// and provoke a certain action to be taken on the server.
	/// </summary>
	public class VPJRequestFactory
	{

		/// <summary>
		/// Creates a fully initialized ActivationRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new ActivationRequest </returns>
		public virtual POSActivationRequest createActivationRequest()
		{
			return new POSActivationRequest();
		}

		/// <summary>
		/// Creates a fully initialized ConfigRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new ConfigRequest </returns>
		public virtual POSConfigRequest createConfigRequest()
		{
			return new POSConfigRequest();
		}

		/// <summary>
		/// Creates a fully initialized DeactivationRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new DeactivationRequest </returns>
		public virtual POSDeactivationRequest createDeactivationRequest()
		{
			return new POSDeactivationRequest();
		}

		/// <summary>
		/// Creates a fully initialized ReprintReceiptRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new ReprintReceiptRequest </returns>
		public virtual POSReprintReceiptRequest createReprintReceiptRequest()
		{
			return new POSReprintReceiptRequest();
		}

		/// <summary>
		/// Creates a fully initialized TrxLogReceiptRequest to send to the Vibbek CS via VPJ.
		/// </summary>
		/// <returns> a new request object </returns>
		public virtual POSTrxLogReceiptRequest createTrxLogReceiptRequest()
		{
			return new POSTrxLogReceiptRequest();
		}

		/// <summary>
		/// Creates a fully initialized <seealso cref="POSCheckCouponIdRequest"/>.
		/// </summary>
		/// <returns> a new request object. </returns>
		public virtual POSCheckCouponIdRequest createCheckCouponIdRequest()
		{
			return new POSCheckCouponIdRequest();
		}

		/// <summary>
		/// Creates a fully initialized FinalBalanceRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new FinalBalanceRequest </returns>
		public virtual POSFinalBalanceRequest createFinalBalanceRequest()
		{
			return new POSFinalBalanceRequest();
		}

		/// <summary>
		/// Creates a fully initialized ConfigDataRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new POSConfigDataRequest </returns>
		public virtual POSConfigDataRequest createConfigDataRequest()
		{
			return new POSConfigDataRequest();
		}

		/// <summary>
		/// Creates a fully initialized InitRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new InitRequest </returns>
		public virtual POSInitRequest createInitRequest()
		{
			return new POSInitRequest();
		}

		/// <summary>
		/// Creates a fully initialized PaymentRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new PaymentRequest </returns>
		public virtual POSPaymentRequest createPaymentRequest()
		{
			return new POSPaymentRequest();
		}

		/// <summary>
		/// Creates a fully initialized PingRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new PingRequest </returns>
		public virtual POSPingRequest createPingRequest()
		{
			return new POSPingRequest();
		}

		/// <summary>
		/// Creates a fully initialized ReversalRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new ReversalRequest </returns>
		public virtual POSReversalRequest createReversalRequest()
		{
			return new POSReversalRequest();
		}

		/// <summary>
		/// Creates a CancelReservationRequest to send to the Vibbek CS via VPJ. </summary>
		/// <returns> A new CancelReservationRequest </returns>
		public virtual POSCancelReservationRequest createCancelReservationRequest()
		{
			return new POSCancelReservationRequest();
		}

		/// <summary>
		/// Creates a fully initialized SubmissionRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new SubmissionRequest </returns>
		public virtual POSSubmissionRequest createSubmissionRequest()
		{
			return new POSSubmissionRequest();
		}

		/// <summary>
		/// Creates a fully initialized TransmissionRequest to send
		/// to the Vibbek CS via VPJ. </summary>
		/// <returns> A new TransmissionRequest </returns>
		public virtual POSTransmissionSubmissionRequest createTransmissionSubmissionRequest()
		{
			return new POSTransmissionSubmissionRequest();
		}

		/// <summary>
		/// Creates an AbortCardEntryNotification to send to the VPJ.
		/// </summary>
		/// <returns> a new AbortCardEntryNotification. </returns>
		public virtual POSAbortCardEntryNotification createAbortCardEntryNotification()
		{
			return new POSAbortCardEntryNotification();
		}

		/// <summary>
		/// Creates a POSIntermediateEodReceiptRequest to send to the Vibbek CS via VPJ.
		/// </summary>
		/// <returns> A new <seealso cref="POSIntermediateEodReceiptRequest"/> </returns>
		public virtual POSIntermediateEodReceiptRequest createIntermediateEodReceiptRequest()
		{
			return new POSIntermediateEodReceiptRequest();
		}

		/// <summary>
		/// Creates a POSPinpadInformationRequest to send to VPJ.
		/// </summary>
		/// <returns> A new <seealso cref="POSPinpadInformationRequest"/> </returns>
		public virtual POSPinpadInformationRequest createPOSPinpadInformationRequest()
		{
			return new POSPinpadInformationRequest();
		}

	}

}