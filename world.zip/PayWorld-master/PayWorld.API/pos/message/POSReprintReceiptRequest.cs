﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Instances of this class represent a request to trigger a reprint receipt, requested by the POS.
	/// 
	/// @author dbuck
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "reprintReceiptRequest") public class POSReprintReceiptRequest extends AbstractPOSRequest
	public class POSReprintReceiptRequest : AbstractPOSRequest
	{

		private string type;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "type") public String getType()
		public virtual string Type
		{
			get
			{
				return this.type;
			}
			set
			{
				this.type = value;
			}
		}


	}

}