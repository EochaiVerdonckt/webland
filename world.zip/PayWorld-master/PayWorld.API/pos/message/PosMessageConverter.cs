﻿namespace com.vibbek.client.pos.message
{

	using DefaultRuntimeException = com.vibbek.util.ex.DefaultRuntimeException;
	using PooledJaxbHelper = com.vibbek.util.xml.PooledJaxbHelper;

	/// <summary>
	/// Converter for conversions between message strings and message instances.
	/// 
	/// @author aguenther
	/// </summary>
	public sealed class PosMessageConverter
	{

		private const string CONTEXT_PATH = "com.vibbek.client.pos.message";

		private PosMessageConverter()
		{
			// No implementation
		}

		/// <summary>
		/// Parses an POS message string.
		/// </summary>
		/// <param name="message">
		///            the POS message text to parse.
		/// </param>
		/// <returns> the parsed POS message instance.
		/// </returns>
		/// <exception cref="DefaultRuntimeException">
		///             if the message text is not parseable. </exception>
//JAVA TO C# CONVERTER WARNING: 'final' parameters are ignored unless the option to convert to C# 7.2 'in' parameters is selected:
//ORIGINAL LINE: public static IPOSMessage parseMessage(final String message)
		public static IPOSMessage parseMessage(string message)
		{
			try
			{
				return PooledJaxbHelper.Instance.unmarshalXml(message, CONTEXT_PATH);
			}
			catch (JAXBException e)
			{
				throw new DefaultRuntimeException(e);
			}
		}

	}

}