﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Terminal configuration response to a <seealso cref="POSConfigRequest"/> message.
	/// 
	/// @author aflaegel
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "siConfigResponse") public class POSConfigResponse implements IPOSResponse
	public class POSConfigResponse : IPOSResponse
	{

	}

}