﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Response message of a <seealso cref="POSPingRequest"/> message sent to test the connection to the terminal server.
	/// 
	/// @author aguenther
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "pingResponse") public class POSPingResponse implements IPOSResponse
	public class POSPingResponse : IPOSResponse
	{
		// No data included
	}

}