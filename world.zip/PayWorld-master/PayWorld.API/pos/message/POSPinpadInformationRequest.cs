﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// A message sent from the POS to the VPJ to information about the PINpad.
	/// 
	/// @author aguenther
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "pinpadInformationRequest") public class POSPinpadInformationRequest extends AbstractPOSRequest
	public class POSPinpadInformationRequest : AbstractPOSRequest
	{

	}

}