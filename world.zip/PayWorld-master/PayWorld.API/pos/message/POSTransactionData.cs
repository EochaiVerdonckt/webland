﻿using System;

namespace com.vibbek.client.pos.message
{


	using com.vibbek.util.iso;

	/// <summary>
	/// Container for transaction related data.
	/// 
	/// @author mdraeger
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType public class POSTransactionData implements java.io.Serializable
	[Serializable]
	public class POSTransactionData
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlEnum(String.class) public enum PartialApprovalCapType
		public enum PartialApprovalCapType
		{
			NOT_SUPPORTED,
			SUPPORTED
		}

		private const long serialVersionUID = 1L;

		private string amount; // Total amount authorised, i.e. purchase + cashback
		private string amountOther; // i.e. Cashback Amount
		private IsoCurrencyType currency;
		private string transactionType;
		private string authorisationCode;
		private string transactionReferenceNumber;
		private PartialApprovalCapType partialApprovalCapable;
		private string userId;
		private bool? noDCC;
		private bool? forceUP;
		private string arsTransactionNumber;
		private string additionalMerchantData;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "amount", required = true) public String getAmount()
		public virtual string Amount
		{
			get
			{
				return this.amount;
			}
			set
			{
				this.amount = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "currency", required = true) @XmlJavaTypeAdapter(IsoCurrencyTypeAdapter.class) public IsoCurrencyType getCurrency()
		public virtual IsoCurrencyType Currency
		{
			get
			{
				return this.currency;
			}
			set
			{
				this.currency = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "transactionType", required = true) public String getTransactionType()
		public virtual string TransactionType
		{
			get
			{
				return this.transactionType;
			}
			set
			{
				this.transactionType = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "amountOther", required = false) public String getAmountOther()
		public virtual string AmountOther
		{
			get
			{
				return this.amountOther;
			}
			set
			{
				this.amountOther = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "authorisationCode") public String getAuthorisationCode()
		public virtual string AuthorisationCode
		{
			get
			{
				return this.authorisationCode;
			}
			set
			{
				this.authorisationCode = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "transactionRefNumber", required = false) public String getTransactionReferenceNumber()
		public virtual string TransactionReferenceNumber
		{
			get
			{
				return this.transactionReferenceNumber;
			}
			set
			{
				this.transactionReferenceNumber = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "partialApprovalCap", required = false) public PartialApprovalCapType getPartialApprovalCapable()
		public virtual PartialApprovalCapType PartialApprovalCapable
		{
			get
			{
				return this.partialApprovalCapable;
			}
			set
			{
				this.partialApprovalCapable = value;
			}
		}


		public virtual string UserId
		{
			get
			{
				return this.userId;
			}
			set
			{
				this.userId = value;
			}
		}


		public virtual bool? NoDCC
		{
			get
			{
				return this.noDCC;
			}
			set
			{
				this.noDCC = value;
			}
		}


		public virtual bool? ForceUP
		{
			get
			{
				return this.forceUP;
			}
			set
			{
				this.forceUP = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "arsTransactionNumber", required = false) public String getArsTransactionNumber()
		public virtual string ArsTransactionNumber
		{
			get
			{
				return this.arsTransactionNumber;
			}
			set
			{
				this.arsTransactionNumber = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "additionalMerchantData", required = false) public String getAdditionalMerchantData()
		public virtual string AdditionalMerchantData
		{
			get
			{
				return this.additionalMerchantData;
			}
			set
			{
				this.additionalMerchantData = value;
			}
		}

	}

}