﻿namespace com.vibbek.client.pos.message
{
	/// <summary>
	/// This is a marker interface for all messages exchanged between the VPJ client
	/// and the VPJ.
	/// </summary>
	public interface IPOSMessage
	{

	}

}