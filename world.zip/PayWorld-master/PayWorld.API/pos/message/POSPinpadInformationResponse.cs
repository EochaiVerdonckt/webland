﻿//====================================================================================================
//The Free Edition of Java to C# Converter limits conversion output to 100 lines per file.

//To subscribe to the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================

using System.Xml.Serialization;

namespace com.vibbek.client.pos.message
{

    /// <summary>
    /// This represents a response to a <seealso cref="POSPinpadInformationRequest"/> message from the VPJ to the POS. It contains PINpad specific
    /// information.
    /// 
    /// @author aguenther
    /// </summary>
    //JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
    //ORIGINAL LINE: @XmlType @XmlRootElement(name = "pinpadInformationResponse") public class POSPinpadInformationResponse implements IPOSResponse
    public class POSPinpadInformationResponse : IPOSResponse
    {

        private string terminalId;
        private string vpjSoftwareVersion;
        private string serialNumber;
        private string hardwareType;
        private string simCardNumber;
        private string logLevel;
        private string vcsIpAddr;
        private string vcsIpPort;
        private string vcsConnectTimeout;
        private string vcsInactiveTimeout;
        private string pinpadLocalTime;
        private string nextContactTime;
        private string pinpadRunningTime;
        private string freeRamMemory;
        private string freeFlashMemory;
        private string offlineTrxNumber;
        private string offlineTrxAmount;

        public virtual string TerminalId
        {
            set
            {
                this.terminalId = value;
            }
            get
            {
                return this.terminalId;
            }
        }


        public virtual string VpjSoftwareVersion
        {
            set
            {
                this.vpjSoftwareVersion = value;
            }
            get
            {
                return this.vpjSoftwareVersion;
            }
        }


        public virtual string SerialNumber
        {
            set
            {
                this.serialNumber = value;
            }
            get
            {
                return this.serialNumber;
            }
        }


        public virtual string HardwareType
        {
            set
            {
                this.hardwareType = value;
            }
            get
            {
                return this.hardwareType;
            }
        }


        public virtual string SimCardNumber
        {
            set
            {
                this.simCardNumber = value;
            }
            get
            {
                return this.simCardNumber;
            }
        }


        public virtual string LogLevel
        {
            set
            {
                this.logLevel = value;
            }
            get
            {
                return this.logLevel;
            }
        }


        public virtual string VcsIpAddr
        {
            set
            {
                this.vcsIpAddr = value;
            }
            get
            {
                return this.vcsIpAddr;
            }
        }


        public virtual string VcsIpPort
        {
            set
            {
                this.vcsIpPort = value;
            }
            get
            {
                return this.vcsIpPort;
            }
        }


        public virtual string VcsConnectTimeout
        {
            set
            {
                this.vcsConnectTimeout = value;
            }
            get
            {
                return this.vcsConnectTimeout;
            }
        }


        public virtual string VcsInactiveTimeout
        {
            set
            {
                this.vcsInactiveTimeout = value;
            }
            get
            {
                return this.vcsInactiveTimeout;
            }
        }


        public virtual string PinpadLocalTime
        {
            set
            {
                this.pinpadLocalTime = value;
            }
            get
            {
                return this.pinpadLocalTime;
            }
        }


        public virtual string NextContactTime
        {
            set
            {
                this.nextContactTime = value;
            }
            get
            {
                return this.nextContactTime;
            }
        }


        public virtual string PinpadRunningTime
        {
            set
            {
                this.pinpadRunningTime = value;
            }
            get
            {
                return this.pinpadRunningTime;
            }
        }

        [XmlElement(ElementName = "freeRamMemory", IsNullable = false)]
        public virtual string FreeRamMemory
        {
            set
            {
                this.freeRamMemory = value;
            }
            get
            {
                return this.freeRamMemory;
            }
        }
        [XmlElement(ElementName = "freeFlashMemory", IsNullable = false)]
        public virtual string FreeFlashMemory
        {
            set
            {
                this.freeFlashMemory = value;
            }
            get
            {
                return this.freeFlashMemory;
            }
        }
        [XmlElement(ElementName = "offlineTrxNumber", IsNullable = false)]
        public virtual string OfflineTrxNumber
        {
            set
            {
                this.offlineTrxNumber = value;
            }
            get
            {
                return this.offlineTrxNumber;
            }
        }
        [XmlElement(ElementName = "offlineTrxAmount" ,IsNullable =false)]
        public virtual string OfflineTrxAmount
        {
            set
            {
                this.offlineTrxAmount = value;
            }
            get
            {
                return this.offlineTrxAmount;
            }
        }
       
    }

}

