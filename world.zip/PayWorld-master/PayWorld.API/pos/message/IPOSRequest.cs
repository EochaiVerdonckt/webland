﻿namespace com.vibbek.client.pos.message
{
	/// <summary>
	/// This interface defines the methods to be implemented by all representations of requests to be sent to a Vibbek CS via VPJ.
	/// </summary>
	public interface IPOSRequest : IPOSMessage
	{

		/// <summary>
		/// The method to access the value of the POS ID used for this request.
		/// </summary>
		/// <returns> The ID of the POS sending the request. </returns>
		string PosId {get;set;}


	}

}