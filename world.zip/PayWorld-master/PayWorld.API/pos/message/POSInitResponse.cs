﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Terminal initialization response to a <seealso cref="POSInitRequest"/> message.
	/// 
	/// @author aguenther
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "siInitResponse") public class POSInitResponse implements IPOSResponse
	public class POSInitResponse : IPOSResponse
	{

	}

}