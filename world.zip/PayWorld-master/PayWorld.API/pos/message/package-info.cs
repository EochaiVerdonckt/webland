﻿/// <summary>
/// This package contains classes representing the XML messages
/// to be sent to the VPJ.
/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlSchema(namespace = "http://www.vibbek.com/pos", xmlns = { @XmlNs(namespaceURI = "http://www.vibbek.com/pos", prefix = "vcs-pos"), @XmlNs(namespaceURI = "http://www.vibbek.com/device", prefix = "vcs-device") }, elementFormDefault = javax.xml.bind.annotation.XmlNsForm.UNQUALIFIED) package com.vibbek.client.pos.message;
namespace com.vibbek.client.pos.message
{


}