﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// The PoS sends the timeout notification to the VPJ. The PoS sends this message when the user does not react to the confirmation request 
	/// within the timeout.
	/// 
	/// @author mkitschke
	/// 
	/// </summary>
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlType @XmlRootElement(name = "timeoutNotification", namespace = "http://www.vibbek.com/device") public class POSTimeoutNotification implements IPOSMessage
	public class POSTimeoutNotification : IPOSMessage
	{

	}

}