﻿namespace com.vibbek.client.pos.message
{

	/// <summary>
	/// Communication address container.
	/// 
	/// @author aguenther
	/// </summary>
	public class POSCommunicationAddressContainer
	{

		private string internetAddr;
		private string internetPortNo;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "internetAddr", required = false) public String getInternetAddr()
		public virtual string InternetAddr
		{
			get
			{
				return internetAddr;
			}
			set
			{
				this.internetAddr = value;
			}
		}


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @XmlElement(name = "internetPortNo", required = false) public String getInternetPortNo()
		public virtual string InternetPortNo
		{
			get
			{
				return internetPortNo;
			}
			set
			{
				this.internetPortNo = value;
			}
		}

	}

}