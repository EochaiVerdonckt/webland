﻿namespace com.vibbek.client.pos
{
	using com.vibbek.client.pos.message;

	/// <summary>
	/// The PoS simulator provides the dialogs for the interaction with a user by this interface.
	/// 
	/// @author mkitschke
	/// 
	/// </summary>
	public interface IPosInteractionHandler
	{

		/// <summary>
		/// This method shows the confirmation request dialog and returns a message object depending on what the user has selected in the dialog.
		/// </summary>
		/// <param name="timeout"> timeout in seconds. </param>
		/// <returns> a <seealso cref="POSConfirmationResponse"/> or a <seealso cref="POSTimeoutNotification"/> object. </returns>
		IPOSMessage showConfirmationRequestDialog(int timeout);

		/// <summary>
		/// Shows the dialog to enter a new transaction amount and a new PAN to modify manor transactions.
		/// </summary>
		/// <returns> a <seealso cref="POSManorTrxModificationResponse"/> containing the possibly modified transaction data or a
		///         <seealso cref="POSTimeoutNotification"/> if the amount was not provided in time. </returns>
		IPOSMessage showManorTransactionModificationDialog();
	}

}