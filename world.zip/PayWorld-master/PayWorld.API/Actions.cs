﻿using PayWorld.API.Messages.Device;
using PayWorld.API.Messages.Pos;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;

namespace PayWorld.API.Helpers
{
    internal static class TerminalActions
    {
        private static PayWorldTcpClient _activePayWorldClient;
        private static string _ipOrHostname;
        private static int _port;
        private static int _timeoutInMiliSecondsForTransactions;


        public delegate void OnPingPongCompletedDelegate(PingResponse data);
        public static event OnPingPongCompletedDelegate OnPingPongCompleted;
        public delegate void OnErrorNotificationCompletedDelegate(ErrorNotification data);
        public static event OnErrorNotificationCompletedDelegate OnErrorNotificationCompleted;
        public delegate void OnDisplayNotificationCompletedDelegate(DisplayNotification data);
        public static event OnDisplayNotificationCompletedDelegate OnDisplayNotificationCompleted;
        public delegate void OnPrinterNotificationCompletedDelegate(PrinterNotification data);
        public static event OnPrinterNotificationCompletedDelegate OnPrinterNotificationCompleted;
        public delegate void OnNotificationCompletedDelegate(string data);
        public static event OnNotificationCompletedDelegate OnNotificationCompleted;
        public delegate void OnConfirmationRequestDelegate(ConfirmationRequest data);
        public static event OnConfirmationRequestDelegate OnConfirmationRequestCompleted;
        public delegate void OnFinancialTrxResponseCompletedDelegate(FinancialTrxResponse data);
        public static event OnFinancialTrxResponseCompletedDelegate OnFinancialTrxResponseCompleted;
        public delegate void OnBeFinalBalanceResponseCompletedDelegate(BeFinalBalanceResponse data);
        public static event OnBeFinalBalanceResponseCompletedDelegate OnBeFinalBalanceResponseCompleted;


        public static string LastSendMessage;
        public static string LastReceivedMessage;
        public static string LastDisplayNotificationAsString;
        public static ErrorNotification LastErrorNotification;
        public static DisplayNotification LastDisplayNotification;
        public static PrinterNotification LastPrinterNotification;
        public static string LastNotification;
        public static ConfirmationRequest LastConfirmationRequest;
        public static PingResponse LastPingPongResponse;
        public static FinancialTrxResponse LastFinancialTrxResponse;
        public static BeFinalBalanceResponse LastBeFinalBalanceResponse;

        public static void Init(string ipOrHostname, int port, int timeoutInMiliSecondsForTransactions)
        {
            _ipOrHostname = ipOrHostname;
            _port = port;
            _timeoutInMiliSecondsForTransactions = timeoutInMiliSecondsForTransactions;
        }

        public static async Task<string> SendGenericMessage(string data, bool abort = false)
        {
            LastSendMessage = data;
            if (_activePayWorldClient != null && !abort)
            {
                _activePayWorldClient.MessageReceived -= _activePayWorldClient_MessageReceived;
                _activePayWorldClient?.Dispose();
                _activePayWorldClient = null;
            }
            if (_activePayWorldClient == null)
            {
                _activePayWorldClient = new PayWorldTcpClient(_ipOrHostname, _port, _timeoutInMiliSecondsForTransactions);
                _activePayWorldClient.MessageReceived += _activePayWorldClient_MessageReceived;
                await _activePayWorldClient?.Connect();
            }
            Debug.Write(data);
            if (abort)
            {
                _activePayWorldClient?.AbortTransaction(data);
                return "";
            }

            return await _activePayWorldClient?.SendMessage(data);


        }

        public static async Task<(string, string)> SendPing()
        {
            PingRequest request = new PingRequest();
            string result = await SendGenericMessage(request.PosXmlSerialize());
            return (result, request.PosXmlSerialize());
        }

        public static async Task<(string, string)> SendTransaction(string amount, string posId, Byte[] trxInfo = null, PayWorld.API.Messages.Pos.CurrencyType currencyType = PayWorld.API.Messages.Pos.CurrencyType.Item978)
        {
            // CurrencyType.Item978 = EURO
            ulong amountPos = ulong.Parse(amount);
            FinancialTrxRequest request = new FinancialTrxRequest
            {
                posId = posId
            };
            // trx info - receive notifications - see topic 9.1.1 trxInfo bitmask
            Byte[] bytes = new Byte[3] { 0, 0, 3 };
            if (trxInfo == null)
            {
                request.trxInfo = bytes;
            }
            else
            {
                request.trxInfo = trxInfo;
            }

            request.trxData = new TransactionData() { amount = amountPos, currency = currencyType, transactionType = TransactionType.Purchase };



            return (await SendGenericMessage(request.PosXmlSerialize()), request.PosXmlSerialize());
        }

        private static void _activePayWorldClient_MessageReceived(object sender, EventArgs e)
        {
            ProcessMessage((PayWorldTcpClient)sender);
        }

        private static void ProcessMessage(PayWorldTcpClient payWorldTcpClient)
        {
            string message = payWorldTcpClient.LastMassageReveived;
            LastReceivedMessage = message;
            Debug.WriteLine(LastReceivedMessage);
            if (!String.IsNullOrEmpty(message))
            {
                Type responseType = PosTypeResolver.GetType(message);
                if (responseType == null)
                {
                    _activePayWorldClient.Dispose();
                    _activePayWorldClient = null;
                    return;
                }
                string result = "";

                if (responseType.Equals(typeof(PingResponse)))
                {
                    // sample:
                    PingResponse response = message.PosXmlDeserialize<PingResponse>();

                    LastPingPongResponse = response;
                    OnPingPongCompleted(response);

                }
                if (responseType.Equals(typeof(ErrorNotification)))
                {
                    // sample:
                    ErrorNotification error = message.PosXmlDeserialize<ErrorNotification>();
                    result = error.errorText;
                    LastErrorNotification = error;
                    OnErrorNotificationCompleted(error);


                }
                if (responseType.Equals(typeof(DisplayNotification)))
                {
                    LastDisplayNotificationAsString = message;
                    DisplayNotification notification = message.PosXmlDeserialize<DisplayNotification>();
                    // act on this return
                    result = $"{notification.display.line.First()} - {notification.displayType}";
                    LastDisplayNotification = notification;
                    OnDisplayNotificationCompleted(notification);


                }
                if (responseType.Equals(typeof(FinancialTrxResponse)))
                {
                    // sample:
                    // act on this return
                    FinancialTrxResponse data = message.PosXmlDeserialize<FinancialTrxResponse>();
                    LastFinancialTrxResponse = data;
                    OnFinancialTrxResponseCompleted(data);
                    //Stop logic


                }

                if (responseType.Equals(typeof(CardRemovalNotification)))
                {
                    // sample:
                    // act on this return
                    CardRemovalNotification data = message.PosXmlDeserialize<CardRemovalNotification>();

                    // Do something with it
                    LastNotification = message;
                    OnNotificationCompleted(nameof(CardRemovalNotification));

                }


                if (responseType.Equals(typeof(ConfirmationRequest)))
                {
                    // sample:
                    // act on this return
                    ConfirmationRequest data = message.PosXmlDeserialize<ConfirmationRequest>();
                    result = data.displayType.ToString();

                    if (data.display != null)
                    {
                        result += Environment.NewLine;
                        foreach (string s in data.display.line)
                        {
                            result += s + Environment.NewLine;
                        }
                    }
                    // Do something with it
                    LastConfirmationRequest = data;
                    OnConfirmationRequestCompleted(data);


                }

                if (responseType.Equals(typeof(CardEntryNotification)))
                {
                    // sample:
                    // act on this return
                    CardEntryNotification data = message.PosXmlDeserialize<CardEntryNotification>();

                    // Do something with it
                    LastNotification = message;
                    OnNotificationCompleted(nameof(CardEntryNotification));

                }
                if (responseType.Equals(typeof(BeFinalBalanceResponse)))
                {
                    // sample:
                    var data = message.PosXmlDeserialize<BeFinalBalanceResponse>();
                    // act on this return
                    var synNumber = data.trxSyncNumber;
                    LastBeFinalBalanceResponse = data;
                    OnBeFinalBalanceResponseCompleted(data);


                }

                if (responseType.Equals(typeof(PrinterNotification)))
                {
                    // sample:
                    var data = message.PosXmlDeserialize<PrinterNotification>();

                    // act on this return  
                    LastPrinterNotification = data;
                    OnPrinterNotificationCompleted(data);
                }
            }
        }
    }
}
