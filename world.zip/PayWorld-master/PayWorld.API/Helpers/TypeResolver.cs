﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace PayWorld.API.Helpers
{
    public static class PosTypeResolver
    {
        public static Type GetType(string message)
        {
            message = message.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            message = message.Replace("\n", "");
            message = message.Replace("<vcs-device:", "").Split(' ')[0];
            message = message.Replace("<vcs-pos:", "").Split(' ')[0];
            string messageFull = "PayWorld.API.Messages.Device." + FirstCharToUpper(message);            
            var type = System.Type.GetType(messageFull);
            if(type == null)
            {
                messageFull = "PayWorld.API.Messages.Pos." + FirstCharToUpper(message);
            }
            type = System.Type.GetType(messageFull);
            return type;
        }
        private static string FirstCharToUpper(string input)
        {           
            return input.First().ToString().ToUpper() + input.Substring(1);
        }

    }
}
