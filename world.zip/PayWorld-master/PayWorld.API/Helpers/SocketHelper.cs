﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace PayWorld.API.Helpers
{
    /// <summary>
    /// This class is a helper class to facilitate more straight forward communication with the pay terminal.
    /// </summary>
    internal static class SocketHelper
    {
        /// <summary>
        /// In order for the pay terminal to know when the message that we send is complete we prefix the message with the length of the message represented in bytes.        /// 
        /// </summary>
        /// <param name="data">The xml message we will send.</param>
        /// <returns>Bytearray of 4 bytes containing the number of bytes of the following XML message appended with the XML message represented in bytes.</returns>
        public static byte[] PosData(string data)
        {
            int byteCount = new UTF8Encoding(false).GetByteCount(data);
            byte[] bytes = BitConverter.GetBytes(byteCount);
            Array.Reverse(bytes);
            byte[] message = new UTF8Encoding(false).GetBytes(data);
            return bytes.Concat(message).ToArray();
        }
        /// <summary>
        /// The first 4 bytes we receive back contains the lengh of the bytes we should read next.
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns>Length of the bytearray we should read from the socket.</returns>
        public static int PosReturnLength(byte[] bytes)
        {
            if (BitConverter.IsLittleEndian)
                Array.Reverse(bytes);
            return BitConverter.ToInt32(bytes, 0);
        }
    }
}
